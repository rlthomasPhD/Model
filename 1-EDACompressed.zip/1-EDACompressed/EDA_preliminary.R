# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Combine and explore source data 
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse", 
          "lubridate" 
)


if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

# source("//gs_data/tools/grstools_temp/R/onewaytab.R")
# source("//gs_data/tools/grstools_temp/R/duallift.R")
# source("//gs_data/tools/grstools_temp/R/gainchart.R")
# source("//gs_data/tools/grstools_temp/R/liftchart.R")
# source("//gs_data/tools/grstools_temp/R/utility.R")
# source("//gs_data/tools/grstools_temp/R/weightedbucket.R")
source("//gs_data/tools/libertyr_update/EDA_default.R")
source("//gs_data/tools/libertyr_update/EDA_plot.R")
source("//gs_data/tools/libertyr_update/EDA_report.R")
source("//gs_data/tools/libertyr_update/report.R")

# -------------------------
# 1. Load Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")
df2013 <- fread("WC 2013 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2014 <- fread("WC 2014 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2015 <- fread("WC 2015 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2016 <- fread("WC 2016 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2017 <- fread("WC 2017 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2018 <- fread("WC 2018 Data.csv", encoding='UTF-8', stringsAsFactors=FALSE)

names(df2013)

# sanity check
names(df2013) == names(df2014) 
names(df2014) == names(df2015) 
names(df2015) == names(df2016) 
names(df2016) == names(df2017)
names(df2017) == names(df2018)

# combine and save data
df <- rbind(df2013, df2014, df2015, df2016, df2017, df2018)

# -------------------------
# 2. Explore Data
# -------------------------
glimpse(df)

length(unique(df$Claim_ID)) == nrow(df) # TRUE 1761705
length(unique(df$Claim_Num)) == nrow(df) # TRUE 1761705
# data unique by Claim_ID and Claim_Num 

# preliminary data formatting
df <- df %>% mutate_at(vars(Indemnity_Incurred, 
                            Medical_Incurred, 
                            Expense_Incurred,
                            Claimant_Age_Qty,
                            Tenure),
                       as.double) %>%
  mutate_if(is.integer, as.character) %>%
  mutate_at(vars(Claim_System_Entry_Dte ,
                 Report_dte,
                 Injury_Dte), funs(as.Date(.,"%d%b%Y"))) 

glimpse(df)  

# EDA
system.time(# 781.312  
  dfeda <- eda(df, byvar = TRUE)
)

dfeda$data_summary
dfeda$date_summary
dfeda$num_summary
dfeda$cat_summary

df <- df %>% mutate(deEscInd3500 = ifelse(Initial_Seg != "SUS" &
                                            (current_total_incurred <= 3500 |
                                               is.na(current_total_incurred)), 1,0))

ignrCol <- dfeda$cat_summary %>%
  filter(unique_levels == 1 | unique_levels > 100) %>% 
  pull(var_name)

percent(table(df$deEscInd3500)/nrow(df))
# 0   1 
# 64% 36% 

system.time(# 74.168
  edaBySeg <- eda(df, crossvar = c("deEscInd3500","Year"), cross_only = TRUE, ignore_list = ignrCol)
)
edaByDSegPlots <- plot(edaBySeg)

edaBySeg$num_cross$deEscInd3500
#de-esclate acount have a very slightly shorter tenure
#de-esclate acount have a very different wage distribution, with a lot more zeros
edaBySeg$num_cross$Year
# claims distributions are consistent across year with 2018 to be significantly better than the otheryears
# 2018 has lower wage amount, more zeroes

edaBySeg$cat_cross$deEscInd3500
# open claims are less likely to be de-escalated
# TX claims might be more likely to be de-escalated, while IL claims might be less likely
# Service center intake regardless of communication method may be more likely to be de-escalated
# 52 primary nature of injury may be more likely to be de-escalated; 37, 28, 59 might as well
# 52 secondary nature of injury may be more likely to be de-escalated; 37, 53, 68 might as well
# 10, 42, 34 primary body part of injury may be more likely to be de-escalated;
# 2, 3 initial treatment might be more likely to be de-escalated;
# MMU today's bucket might be more likely to be de-escalated;
# MMU initial bucket might be more likely to be de-escalated;

edaBySeg$cat_cross$Year
#increasing CA, TX, GA claims 
# increasing EDI take, service center email; (slightly more call center and prior TPA in 2018)
# decreasing internet intake??? (significant drop in 2018), service center telephone, SC fax, fax/written
# started customer self-report in 2018
# primary nature of injury: more 59(un classified) in 2018, less burn throughout the years
# decreaing 42, increasing 10, 56
# treatment - increase 1 decrease 3
# segment today - increasing MMU and CST, much less CPX in 2018, might have not been developed
#initial segment - decreasing SUS and increasing MMU


# explore occupancy type

View(df %>% 
       group_by(Occupation_Txt) %>% 
       tally() %>% arrange(desc(n)) %>% filter(n >= 100))

#list abnormal occupation code
ocpCode1 <- df %>% 
  filter(endsWith(Occupation_Txt,"COMM")) %>% 
  group_by(Occupation_Txt) %>% 
  tally() %>% arrange(desc(n))

ocpCode2 <- df %>% 
  filter(grepl("CLAIMS -", Occupation_Txt)) %>% 
  group_by(Occupation_Txt) %>% 
  tally() %>% arrange(desc(n))

ocpCode3 <-  df %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt))%>% 
  filter(!endsWith(Occupation_Txt,"COMM")) %>%
  filter(!grepl("CLAIMS -", Occupation_Txt)) %>% 
  group_by(Occupation_Txt) %>% tally()%>% 
  arrange(desc(n))

df %>% filter(endsWith(Occupation_Txt,"COMM")) %>% group_by(Year) %>% tally()
df %>% filter(endsWith(Occupation_Txt,"COMM")) %>% group_by(Intake_Method) %>% tally()

df %>% filter(grepl("CLAIMS -", Occupation_Txt)) %>% 
  group_by(Year) %>% 
  tally() %>% arrange(desc(n))

df %>% filter(grepl("CLAIMS -", Occupation_Txt)) %>% 
  group_by(Intake_Method) %>% 
  tally() %>% arrange(desc(n))

ocpCode4_SC <- df %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt))%>% 
  filter(!endsWith(Occupation_Txt,"COMM")) %>%
  filter(!grepl("CLAIMS -", Occupation_Txt)) %>% 
  filter(startsWith(Intake_Method, "Service")) %>%
  group_by(Occupation_Txt) %>% tally()%>% 
  arrange(desc(n))

ocpCode4_EDI <- df %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt))%>% 
  filter(!endsWith(Occupation_Txt,"COMM")) %>%
  filter(!grepl("CLAIMS -", Occupation_Txt)) %>% 
  filter(Intake_Method=='EDI') %>%
  group_by(Occupation_Txt) %>% tally()%>% 
  arrange(desc(n))

ocpCode4_Int <- df %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt))%>% 
  filter(!endsWith(Occupation_Txt,"COMM")) %>%
  filter(!grepl("CLAIMS -", Occupation_Txt)) %>% 
  filter(Intake_Method=='Internet') %>%
  group_by(Occupation_Txt) %>% tally()%>% 
  arrange(desc(n))

df %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt)) %>% 
  group_by(Account_Name) %>% 
  tally() %>% 
  arrange(desc(n))

df %>% 
  filter(Account_Name == "COMCAST CORPORATION") %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt)) %>% 
  select(Account_Name, Occupation_Txt) %>% 
  group_by(Occupation_Txt) %>%
  tally() %>%
  arrange(desc(n)) %>%
  View()

df %>% 
  filter(Account_Name == "UNITED PARCEL SERVICE, INC.") %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt)) %>% 
  select(Account_Name, Occupation_Txt) %>% 
  group_by(Occupation_Txt) %>%
  tally() %>%
  arrange(desc(n)) %>%
  View()

df %>% 
  filter(Account_Name == "ALLSTATE INSURANCE COMPANY") %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt)) %>% 
  select(Account_Name, Occupation_Txt) %>% 
  group_by(Occupation_Txt) %>%
  tally() %>%
  arrange(desc(n)) %>%
  View()

df %>% 
  filter(Account_Name == "UNITED SERVICES AUTOMOBILE") %>% 
  filter(grepl('[[:digit:]]+', Occupation_Txt)) %>% 
  select(Account_Name, Occupation_Txt) %>% 
  group_by(Occupation_Txt) %>%
  tally() %>%
  arrange(desc(n)) %>%
  View()



# -------------------------
# 3. Export Data
# -------------------------
fwrite(df, "WC_all_data.csv",row.names = FALSE )
saveRDS(df, file = "WC_all_data.rds")

