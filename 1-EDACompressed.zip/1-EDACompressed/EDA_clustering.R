# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Perform clustering analysis on building data
# ===========================================================================================

# -------------------------
# 1. Set Preambles
# -------------------------
libs <- c("data.table", 
          "tidyverse", 
          "lubridate",
          "caret",
          "readxl",
          "openxlsx",
          "fuzzyjoin",
          "tm",
          "cluster",
          "factoextra",
          "NbClust",
          "gRstools"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

#-------------------------- a function from Lynn: writing data to excel files--------------------
tbl_to_sheet <- function(dir, workbookName, sheetName, tbl,...) {
  # This function takes a table and write it to an excel file
  excelFile <- paste0(dir, workbookName)
  if (!file.exists(excelFile)){
    wb <- createWorkbook()
  } else{
    wb <- openxlsx::loadWorkbook(file = excelFile)
    if (any(getSheetNames(excelFile)==sheetName)) {
      openxlsx::removeWorksheet(wb, sheetName)
      openxlsx::saveWorkbook(wb, excelFile, overwrite=TRUE)
      wb <- openxlsx::loadWorkbook(file = excelFile)
    }
  }
  
  
  addWorksheet(wb, sheetName)
  writeData(wb, sheet = sheetName, x = tbl, startCol = 1, startRow = 1)
  
  openxlsx::saveWorkbook(wb, file = excelFile, overwrite = TRUE)
}

# set seed
set.seed(3527)

# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
setwd("//PDC-AIP-DATA.LM.LMIG.COM/ETS_ASE_GS_NAS_T3_Prod01/CynthiaH/NI WC Claims")
df <- readRDS("WC_DeEscl_Data_Build_v2.rds")

# ----------------------------------
# 3. Prepare Clustering Measurement
# ----------------------------------

univarLoss <- function(df, varlist){
  tbl <- list()
  for (var in varlist){
    tbl[[var]] <-df %>% 
      group_by_(var) %>%
      summarise(total_loss = sum(current_total_incurred, na.rm = TRUE),
                avg_total_loss = mean(current_total_incurred, na.rm = TRUE),
                med_total_loss = median(current_total_incurred, na.rm = TRUE),
                Q3_total_loss = quantile(current_total_incurred, 0.75, na.rm = TRUE),
                var_total_loss = var(current_total_incurred, na.rm = TRUE),
                medical_loss = sum(Medical_Incurred, na.rm = TRUE),
                avg_medical_loss = mean(Medical_Incurred, na.rm = TRUE),
                med_medical_loss = median(Medical_Incurred, na.rm = TRUE),
                Q3_medical_loss = quantile(Medical_Incurred, 0.75, na.rm = TRUE),
                var_medical_loss = var(Medical_Incurred, na.rm = TRUE),
                indem_loss = sum(Indemnity_Incurred, na.rm = TRUE),
                avg_indem_loss = mean(Indemnity_Incurred, na.rm = TRUE),
                med_indem_loss = median(Indemnity_Incurred, na.rm = TRUE),
                Q3_indem_loss = quantile(Indemnity_Incurred, 0.75, na.rm = TRUE),
                var_indem_loss = var(Indemnity_Incurred, na.rm = TRUE),
                exp_loss = sum(Expense_Incurred, na.rm = TRUE),
                avg_exp_loss = mean(Expense_Incurred, na.rm = TRUE),
                med_exp_loss = median(Expense_Incurred, na.rm = TRUE),
                Q3_exp_loss = quantile(Expense_Incurred, 0.75, na.rm = TRUE),
                var_exp_loss = var(Expense_Incurred, na.rm = TRUE),
                freq = n()) %>% 
      arrange(desc(med_total_loss), 
              desc(avg_total_loss),
              desc(freq))
  }
  return(tbl)
}

clusterResDescl <- univarLoss(df, varlist = c("Prim_NOI_Dsc",
                                              "Scd_NOI_Dsc",
                                              "Prim_POB_Dsc",
                                              "Scd_POB_Dsc",
                                              "Initial_Trtm_Cde",
                                              "Occur_Dsc",
                                              "Intake_Method"))

# -------------------------
# 4. Cluster Analysis
# -------------------------

# 4.1 Part of Body Injured ################################################

PrimPOB <- clusterResDescl$Prim_POB_Dsc 
ds1 <- PrimPOB %>% 
        select(avg_total_loss,
               med_total_loss,  
               avg_medical_loss,
               med_medical_loss,
               avg_indem_loss,  
               # med_indem_loss, # this column is all zero for PrimPOB
               avg_exp_loss,
               med_exp_loss) %>%
        scale() 

row.names(ds1) <-  PrimPOB$Prim_POB_Dsc

gradient.color <- list(low = "steelblue",  high = "white")
ds1 %>% 
  get_clust_tendency(n = 50,
                     gradient = gradient.color)
# 3~4 clusters

# k means-====================================

#remove outlier categories 
ds1_adj <- ds1[-which(rownames(ds1) %in% c("Disc in neck", 
                                           "Spinal cord (low or middle back area)",
                                           "Disc in low or middle back",
                                           "Vertebrae in neck")),]

## Optimal number of clusters

#elbow method
fviz_nbclust(ds1_adj, 
             FUNcluster = kmeans, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 4 clusters

#average silhouette method
fviz_nbclust(ds1_adj, 
             FUNcluster = kmeans, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 2 clusters

#average silhouette method
fviz_nbclust(ds1_adj, 
             FUNcluster = kmeans, 
             method = "gap_stat", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 1 clusters

km.res1.2c <- kmeans(ds1_adj, 2, nstart = 25)
fviz_cluster(km.res1.2c, data = ds1_adj,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())

km.res1.4c <- kmeans(ds1_adj, 4, nstart = 25)
fviz_cluster(km.res1.4c, data = ds1_adj,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())


# k-medoids(PAM)=================================
#elbow method
fviz_nbclust(ds1_adj, 
             FUNcluster = cluster::pam, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 5 clusters

#average silhouette method
fviz_nbclust(ds1_adj, 
             FUNcluster = cluster::pam, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 2 clusters

#average silhouette method
fviz_nbclust(ds1_adj, 
             FUNcluster = cluster::pam, 
             method = "gap_stat", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 10 clusters

pam.res1.2c <- pam(ds1_adj, 2)
fviz_cluster(pam.res1.2c)

pam.res1.5c <- pam(ds1_adj, 5)
fviz_cluster(pam.res1.5c)

cbind(pam = pam.res1.2c$clustering,km = km.res1.2c$cluster) 
#difference in Ankle, Sacrum or coccyx, Multiple body parts 

# ds1_tmp <- as.data.frame(ds1_adj)
ds1_tmp <- data.frame(Prim_POB_Dsc = row.names(ds1_adj),
                      km_2c = km.res1.2c$cluster,
                      km_4c = km.res1.4c$cluster,
                      pam_2c = pam.res1.2c$cluster,
                      pam_5c = pam.res1.5c$cluster
                      )


PrimPOB <- PrimPOB %>% 
            left_join(ds1_tmp, by = "Prim_POB_Dsc") %>% 
            # filter(is.na(km_2c)) %>%
            mutate_at(vars(starts_with("km_"), starts_with("pam_")), as.character) %>%
            mutate_at(vars(starts_with("km"), starts_with("pam")), funs(if_else(is.na(.), Prim_POB_Dsc, .)))


# 4.2 Occurence Code==========================================

Occur <- clusterResDescl$Occur_Dsc

ds2 <- Occur %>% 
        select(avg_total_loss,
               med_total_loss,  
               avg_medical_loss,
               med_medical_loss,
               avg_indem_loss,  
               med_indem_loss, 
               avg_exp_loss,
               med_exp_loss) %>%
        scale() 

row.names(ds2) <-  Occur$Occur_Dsc

ds2 %>% 
  get_clust_tendency(n = 50,
                     gradient = gradient.color)
# ~3 clusters

# k means-====================================

#remove outlier categories 
ds2_adj <- ds2[-which(rownames(ds2) %in% c("Crash of airplane", 
                                           "Vehicle upset (overturned)")),]

## Optimal number of clusters

#elbow method
fviz_nbclust(ds2_adj, 
             FUNcluster = kmeans, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 3, 6 clusters

#average silhouette method
fviz_nbclust(ds2_adj, 
             FUNcluster = kmeans, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 4 clusters

#average silhouette method
fviz_nbclust(ds2_adj, 
             FUNcluster = kmeans, 
             method = "gap_stat", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 6 clusters

km.res2.3c <- kmeans(ds2_adj, 3, nstart = 25)
fviz_cluster(km.res2.3c, data = ds2_adj,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())

km.res2.4c <- kmeans(ds2_adj, 4, nstart = 25)
fviz_cluster(km.res2.4c, data = ds2_adj,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())

km.res2.6c <- kmeans(ds2_adj, 6, nstart = 25)
fviz_cluster(km.res2.6c, data = ds2_adj,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())


# k-medoids(PAM)=================================
#elbow method
fviz_nbclust(ds2_adj, 
             FUNcluster = cluster::pam, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 4 clusters

#average silhouette method
fviz_nbclust(ds2_adj, 
             FUNcluster = cluster::pam, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 4 clusters

#average silhouette method
fviz_nbclust(ds2_adj, 
             FUNcluster = cluster::pam, 
             method = "gap_stat", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 9 clusters

pam.res2.4c <- pam(ds2_adj, 4)
fviz_cluster(pam.res2.4c)

pam.res2.9c <- pam(ds2_adj, 9)
fviz_cluster(pam.res2.9c)


# ds2_tmp <- as.data.frame(ds2_adj)
ds2_tmp <- data.frame(Occur_Dsc = row.names(ds2_adj),
                      km_3c = km.res2.3c$cluster,
                      km_4c = km.res2.4c$cluster,
                      km_6c = km.res2.6c$cluster,
                      pam_4c = pam.res2.4c$cluster,
                      pam_9c = pam.res2.9c$cluster
)


Occur <- Occur %>% 
            left_join(ds2_tmp, by = "Occur_Dsc") %>% 
             # filter(is.na(km_2c)) %>%
            mutate_at(vars(starts_with("km_"), starts_with("pam_")), as.character) %>%
            mutate_at(vars(starts_with("km_"), starts_with("pam_")), funs(if_else(is.na(.), Occur_Dsc, .)))


# 4.3 Primary Nature of Injury ------------------------------------------------


PrimNOI <- clusterResDescl$Prim_NOI_Dsc

ds3 <- PrimNOI %>% 
  select(avg_total_loss,
         med_total_loss,  
         avg_medical_loss,
         med_medical_loss,
         avg_indem_loss,  
         med_indem_loss, 
         avg_exp_loss,
         med_exp_loss) %>%
  scale() 

row.names(ds3) <- PrimNOI$Prim_NOI_Dsc

ds3 %>% 
  get_clust_tendency(n = 50,
                     gradient = gradient.color)
# 3~4 clusters

# k means-====================================


## Optimal number of clusters

#elbow method
fviz_nbclust(ds3, 
             FUNcluster = kmeans, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 6 clusters

#average silhouette method
fviz_nbclust(ds3, 
             FUNcluster = kmeans, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 3 clusters

#average silhouette method
fviz_nbclust(ds3, 
             FUNcluster = kmeans, 
             method = "gap_stat", 
             diss = NULL, k.max = 15, nboot = 100, print.summary = TRUE)
## 12 clusters

km.res3.3c <- kmeans(ds3, 3, nstart = 25)
fviz_cluster(km.res3.3c, data = ds3,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())

km.res3.6c <- kmeans(ds3, 6, nstart = 25)
fviz_cluster(km.res3.6c, data = ds3,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())


km.res3.12c <- kmeans(ds3, 12, nstart = 25)
fviz_cluster(km.res3.12c, data = ds3,
             ellipse.type = "convex",
             palette = "jco",
             ggtheme = theme_minimal())

# k-medoids(PAM)=================================
#elbow method
fviz_nbclust(ds3, 
             FUNcluster = cluster::pam, 
             method = "wss", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 6 clusters

#average silhouette method
fviz_nbclust(ds3, 
             FUNcluster = cluster::pam, 
             method = "silhouette", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 7 clusters

#average silhouette method
fviz_nbclust(ds3, 
             FUNcluster = cluster::pam, 
             method = "gap_stat", 
             diss = NULL, k.max = 10, nboot = 100, print.summary = TRUE)
## 9 clusters

pam.res3.6c <- pam(ds3, 6)
fviz_cluster(pam.res3.6c)

pam.res3.7c <- pam(ds3, 7)
fviz_cluster(pam.res3.7c)

pam.res3.9c <- pam(ds3, 9)
fviz_cluster(pam.res3.9c)

# ds3_tmp <- as.data.frame(ds3)
ds3_tmp <- data.frame(Prim_NOI_Dsc = row.names(ds3),
                      km_3c = km.res3.3c$cluster,
                      km_6c = km.res3.6c$cluster,
                      km_12c = km.res3.12c$cluster,
                      pam_6c = pam.res3.6c$cluster,
                      pam_7c = pam.res3.7c$cluster,
                      pam_9c = pam.res3.9c$cluster
)

PrimNOI <- PrimNOI %>% 
  left_join(ds3_tmp, by = "Prim_NOI_Dsc") %>% 
  # filter(is.na(km_2c)) %>%
  mutate_at(vars(starts_with("km_"), starts_with("pam_")), as.character) %>%
  mutate_at(vars(starts_with("km_"), starts_with("pam_")), funs(if_else(is.na(.), Prim_NOI_Dsc, .)))

# save results
save.image("/gs_data/CynthiaH/NI WC Claims/EDA_clustering.RData")

# load("clusterGrp.RData")

 
