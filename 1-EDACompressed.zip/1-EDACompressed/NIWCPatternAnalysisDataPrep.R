# ===========================================================================================
# Project: NI WC Claims Segmentation
# Task: Pattern analysis
# Author: Cynthia He
# Date: 04/23/2019
# 
# Objective: Find business meaningful pocket that can be de-escalated in segmentation
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse", 
          "lubridate",
          "caret",
          "readxl",
          "openxlsx",
          "fuzzyjoin",
          "tm",
          "cluster",
          "factoextra",
          "NbClust",
          "scales",
          "knitr"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

source("//gs_data/tools/grstools_temp/R/weightedbucket.R")
source("//gs_data/tools/libertyr_update/EDA_default.R")
source("//gs_data/tools/libertyr_update/EDA_plot.R")
source("//gs_data/tools/libertyr_update/EDA_report.R")
source("//gs_data/tools/libertyr_update/report.R")

# -------------------------
# 2. Load and Process Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")
df <- readRDS("WC_modeldf.rds")
POBdef <- read_excel("part of body.xlsx")
NOIdef <- read_excel("Nature of Injury.xlsx")
Occdef <- fread("Occ_def.csv")

# remove policies start in SUS to focus on de-escalation
df <- df %>% filter(Initial_Seg != "SUS") 
# map code description
df <- df %>%
      left_join(POBdef %>% 
                 select(Part_of_Body_Cde, 
                        Part_of_Body_Category_Cde, 
                        Part_of_Body_Dsc, 
                        Part_of_Body_Category_Dsc), 
                  by = c("Primary_Part_Of_Body_Cde" = "Part_of_Body_Cde")) %>%
      rename(Prim_POB_Category_Cde = Part_of_Body_Category_Cde, 
             Prim_POB_Dsc = Part_of_Body_Dsc,
             Prim_POB_Category_Dsc = Part_of_Body_Category_Dsc) %>%
      left_join(POBdef %>% 
                  select(Part_of_Body_Cde, 
                         Part_of_Body_Category_Cde, 
                         Part_of_Body_Dsc, 
                         Part_of_Body_Category_Dsc), 
                by = c("Secondary_Part_Of_Body_Cde" = "Part_of_Body_Cde")) %>%
      rename(Scd_POB_Category_Cde = Part_of_Body_Category_Cde, 
             Scd_POB_Dsc = Part_of_Body_Dsc,
             Scd_POB_Category_Dsc = Part_of_Body_Category_Dsc) %>%
      left_join(Occdef %>% 
                  mutate_if(is.numeric, as.character), 
                  by = "Occurrence_Cde") %>%
      rename(Occur_Dsc = Definition) %>%
      left_join(NOIdef %>% 
                  select(Nature_of_Injury_Code, Nature_of_Injury_Description) %>%
                  mutate(Nature_of_Injury_Code = gsub("(^|[^0-9])0+", "\\1", Nature_of_Injury_Code, perl = TRUE)), 
                by = c("Primary_Nature_Of_Injury_Cde" = "Nature_of_Injury_Code")) %>%
      rename(Prim_NOI_Dsc = Nature_of_Injury_Description) %>%
      left_join(NOIdef %>% 
                  select(Nature_of_Injury_Code, Nature_of_Injury_Description) %>%
                  mutate(Nature_of_Injury_Code = gsub("(^|[^0-9])0+", "\\1", Nature_of_Injury_Code, perl = TRUE)), 
                by = c("Secondary_Nature_Of_Injury_Cde" = "Nature_of_Injury_Code")) %>%
      rename(Scd_NOI_Dsc = Nature_of_Injury_Description) %>%
      mutate_at(vars(Scd_POB_Category_Cde, 
                     Scd_POB_Dsc,
                     Scd_POB_Category_Dsc,
                     Scd_NOI_Dsc),
            funs(if_else(is.na(.), "missing", .))) 

df <- df %>% 
      mutate(deEscInd1000 = as.factor(if_else(current_total_incurred <= 1000, 1,0)))%>% 
      mutate(over100kFlg = as.factor(if_else(current_total_incurred > 100000, 1,0))) %>%
      mutate(zeroLossFlg = if_else(current_total_incurred == 0, 1, 0))

# -------------------------
# 3. Perform EDA
# -------------------------

# define EDA function
multiWayEDA <- function(df, by, countLimit, rateLimit){
  
  n <- nrow(df)
  
  tbl <- df %>% 
    mutate(count = 1) %>%
    group_by(.dots = by) %>% 
    summarise_at(vars(zeroLossFlg, deEscInd1000, deEscInd3000, over100kFlg, count,current_total_incurred), funs(sum(as.numeric(as.character(.)))))%>%
    mutate(zeroLossFlg = zeroLossFlg/count,
           deEscInd1000 = deEscInd1000/count,
           deEscInd3000 = deEscInd3000/count,
           over100kFlg = over100kFlg/count,
           current_total_incurred = current_total_incurred/count,
           cntShare = percent(count/n)) %>%
    rename(avg_total_incurred = current_total_incurred) %>%
    filter_(.dots=list(~count > countLimit))%>% 
    filter_(.dots=list(~deEscInd3000 >= rateLimit)) %>%
    arrange(desc(deEscInd3000), desc(count), desc(deEscInd1000)) %>%
    mutate_at(vars(zeroLossFlg, deEscInd1000, deEscInd3000, over100kFlg), funs(percent(.))) %>%
    select(-count, everything()) # reoder columns
  
  return(tbl)
}

#group numeric variables
df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "age_5grp")

df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight =NULL,
                      Nbin = 8, 
                      newname = "age_8grp")

df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight = NULL,
                      Nbin = 10, 
                      newname = "age_10grp")

df <-  weightedbucket(df, 
                      var = 'Tenure', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "Tenure_5grp")

df <-  weightedbucket(df, 
                      var = 'Avg_Wkly_Wge_Amt', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "Avg_Wkly_Wge_Amt_5grp")

df <-  weightedbucket(df, 
                      var = 'InjurytoReport', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "InjurytoReport_5grp")

df <-  weightedbucket(df, 
                      var = 'ReporttoEntry', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "ReporttoEntry_5grp")

# export data to continue analysis in Rmarkdowm for better reporting format--------------------------------------

saveRDS(df, file = "WC_modeldf4EDA.rds")

# PrimNOI_top20 <- df %>% 
#                   group_by(Prim_NOI_Dsc) %>% 
#                   tally() %>% 
#                   arrange(desc(n)) %>% 
#                   head(20) %>% 
#                   pull(Prim_NOI_Dsc) 
# 
# ScdNOI_top10 <- df %>% 
#                 group_by(Scd_NOI_Dsc) %>% 
#                 tally() %>% 
#                 arrange(desc(n)) %>% 
#                 head(10) %>% 
#                 pull(Scd_NOI_Dsc) 
# 
# PrimPOB_top30 <- df %>% 
#                   group_by(Prim_POB_Dsc) %>% 
#                   tally() %>% 
#                   arrange(desc(n)) %>% 
#                   head(30) %>% 
#                   pull(Prim_POB_Dsc) 
# 
# ScdPOB_top10 <- df %>% 
#                 group_by(Scd_POB_Dsc) %>% 
#                 tally() %>% 
#                 arrange(desc(n)) %>% 
#                 head(10) %>% 
#                 pull(Scd_POB_Dsc) 
# 
# Occur_top30 <- df %>% 
#                 group_by(Occur_Dsc) %>% 
#                 tally() %>% 
#                 arrange(desc(n)) %>% 
#                 head(30) %>% 
#                 pull(Occur_Dsc) 



# perform thorough search

collist2 <- c("age_5grp", "Tenure_5grp", "InjurytoReport_5grp", "ReporttoEntry_5grp",
              "Initial_Trtm_Cde", "Jurisdiction_State_Cde", "Intake_Method", "Prim_POB_Dsc", "Scd_POB_Dsc",
              "Prim_NOI_Dsc", "Scd_NOI_Dsc", "Occur_Dsc", "Occupation_Grp1")

collist2 <- c("age_5grp", "Tenure_5grp", "InjurytoReport_5grp", "Prim_POB_Dsc")
n <- length(collist2)
for (col in collist2){
  i <- which(col == collist2)
  if(i<n){
    for (subcol in collist2[(i+1):n]){
      result <- multiWayEDA(df, by = c(col, subcol), 2500, 0.93)
      if(nrow(result) > 0){
        print(paste(col, "X", subcol))
        print(kable(result))
      }
    }
  }
}
  

list1 <- c("Initial_Seg", "Initial_Trtm_Cde", "Intake_Method")
list2 <- c("age_5grp",  "InjurytoReport_5grp", 
           "Prim_POB_Dsc", "Scd_POB_Dsc",
           "Prim_NOI_Dsc", "Scd_NOI_Dsc", 
           "Occur_Dsc", "Occupation_Grp1")

n <- length(list2)

for (item in list1[1:2]){
  for (col in list2[1:3]){
    i <- which(col == list2)
    if(i<n){
      for (subcol in list2[(i+1):n]){
        result <- multiWayEDA(df, by = c(item, col, subcol), 2500, 0.95)
        if(nrow(result) > 0){
          print(paste(item, "X",col, "X", subcol))
          print(kable(result))
        }
      }
    }
  }
}




