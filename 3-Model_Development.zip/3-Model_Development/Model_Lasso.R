# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: build lasso model for segmentation 
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse", 
          "lubridate", 
          "caret",
          "statmod",
          "lsr",
          "ROCR",
          "AUC",
          "glmnet")

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

set.seed(4235)
# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
setwd("//client/R$/CynthiaH/NI WC Claims")

load("trainTestData.RData" )

# ------------------------------------------
# 3. Data Process
# ------------------------------------------

s1 <- c("Year", "Jurisdiction_State_Cde_Grp", "Intake_Method_Grp",
        "Claimant_Age_Qty", "Gender_Cde", "Tenure", "Avg_Wkly_Wge_Amt",      
        "Initial_Seg", "InjurytoReport", "ReporttoEntry", "PrimNOI_Grp20",
        "ScdNOI_Grp10", "PrimPOB_Grp30", "ScdPOB_Grp10", "Occur_Grp30",       
        "Prim_POB_Category_Dsc", "Scd_POB_Category_Dsc", 
        "Occupation_Grp2",  "Account_Grp2", "NAICS_Grp")

# have to use variables with grouping, otherwise not all levels exist in both train and test partitions
train_df <- cbind.data.frame(X_train, y_train %>% select(-folds)) %>% 
            select(c(s1, "deEscInd3000"))

test_df <- cbind.data.frame(X_test, y_test %>% select(-folds)) %>% 
           select(c(s1, "deEscInd3000"))

# one hot encode data and use LASSO to perform variable selection again
EncodeCol <-  c("PrimNOI_Grp20",             
                "ScdNOI_Grp10",
                "PrimPOB_Grp30",
                "ScdPOB_Grp10",
                "Occur_Grp30",
                "Prim_POB_Category_Dsc",
                "Scd_POB_Category_Dsc",
                "Occupation_Grp2",
                "Account_Grp2",
                "NAICS_Grp" )

dmyTrain <- dummyVars(" ~ .", data = X_train %>% select(EncodeCol))
trainCatEncode <- data.frame(predict(dmyTrain, newdata = X_train %>% select(EncodeCol)))
trainEncode_df <- cbind(train_df %>% select(-one_of(EncodeCol)), trainCatEncode)
trainEncode_mtx <- model.matrix( ~ ., trainEncode_df %>% select(-deEscInd3000))

dmyTest <- dummyVars(" ~ .", data = X_test %>% select(EncodeCol))
testCatEncode <- data.frame(predict(dmyTest, newdata = X_test %>% select(EncodeCol)))
testEncode_df <- cbind(test_df %>% select(-one_of(EncodeCol)), testCatEncode)
testEncode_mtx <- model.matrix( ~ ., testEncode_df %>% select(-deEscInd3000))

save(trainEncode_df, trainEncode_mtx, 
     testEncode_df, testEncode_mtx, 
     file = "lasso_train_test_df_mtx.RData")

load("lasso_train_test_df_mtx.RData")

# ------------------------------------------
# 4. Lasso Model
# ------------------------------------------

# 4.1. fitting -------------------------------

system.time(# 1290.59 
  mod1 <- cv.glmnet(x= as.matrix(trainEncode_mtx), 
                    y= y_train$deEscInd3000, 
                    family="binomial", 
                    type.measure = "class",
                    nfolds=5, 
                    alpha=1)
)

save(mod1, file = "lasso_mod_v1_byErrorRate.RData")

system.time(# 1338.89  
  mod2 <- cv.glmnet(x=as.matrix(trainEncode_mtx), 
                    y=y_train$deEscInd3000, 
                    family="binomial", 
                    type.measure = "auc",
                    nfolds=5, 
                    alpha=1)
)

save(mod2, file="lasso_mod_v2_byAUC.RData")

# 4.2 Evaluation-------------------------------

plot(mod1, 
     main = "LASSO - by Error Rate",
     sub = paste0("lambda.min = ", round(mod1$lambda.min,4), 
                  " lambda.1se = ", round(mod1$lambda.1se,4)))

plot(mod2, 
     main = "LASSO - by AUC",
     sub = paste0("lambda.min = ", round(mod1$lambda.min,4), 
                  " lambda.1se = ", round(mod1$lambda.1se,4)))

# 4.2.1 Minimize error rate model-------------------------------

##method 1: best model with lowest error rate- lambda.min
c1.min<-coef(mod1,s='lambda.min',exact=TRUE)
c1.min.inds<- which(c1.min!=0)
coef1LassoMin <- cbind(row.names(c1.min)[c1.min.inds], c1.min[c1.min.inds])
#removed the intercept row
coef1LassoMin <- data.frame(coef1LassoMin[-1,])
colnames(coef1LassoMin) <- c("var", "coefficient")
#236 non-zero coefficients 
#original levels = 197 + 136(from the not encoded categorical vars) = 333

# tmp <- train_df %>% select(-EncodeCol) %>% names()
# 
# i <- 0
# for (col in tmp){
#   levels <- length(unique(train_df[[col]]))
#   print(col)
#   print(levels)
#   
#   if ()
#   i <- i + levels
# }
# 
# print(i)

##method 2: simpler model with comparable error to the best - lambda.1se
c1.1se<-coef(mod1,s='lambda.1se',exact=TRUE)
c1.1se.inds<-which(c1.1se!=0)
coef1Lasso1se <- cbind(row.names(c1.1se)[c1.1se.inds], c1.1se[c1.1se.inds])
#removed the intercept row
coef1Lasso1se<- data.frame(coef1Lasso1se[-1,])
colnames(coef1Lasso1se) <- c("var", "coefficient")
#188 coefficients

mod1.min.results <- predict(mod1,testEncode_mtx, s="lambda.min")
mod1.min.results.label <- ifelse(mod1.min.results > 0.5, 1,0)
confusionMatrix(y_test$deEscInd3000, 
                as.factor(mod1.min.results.label), 
                mode="everything", 
                positive = "1")
# Reference
# Prediction      0      1
# 0  32074  26830
# 1  28515 130393

# Accuracy : 0.7459          
# 95% CI : (0.7441, 0.7477)
# Precision : 0.8206          
# Recall : 0.8294          
# F1 : 0.8249          

mod1.1se.results <- predict(mod1,testEncode_mtx, s="lambda.1se")
mod1.1se.results.label <- ifelse(mod1.1se.results > 0.5, 1,0)
confusionMatrix(y_test$deEscInd3000, 
                as.factor(mod1.1se.results.label), 
                mode="everything",
                positive = "1")
# Reference
# Prediction      0      1
# 0  31555  27349
# 1  27892 131016

# Accuracy : 0.7464          
# 95% CI : (0.7445, 0.7482)
# Precision : 0.8245          
# Recall : 0.8273          
# F1 : 0.8259  

# 4.2.2 Maximize AUC model-------------------------------

##method 1: best model with lowest error rate- lambda.min
c2.min<-coef(mod2,s='lambda.min',exact=TRUE)
c2.min.inds<- which(c2.min!=0)
coef2LassoMin <- cbind(row.names(c2.min)[c2.min.inds], c2.min[c2.min.inds])
#removed the intercept row
coef2LassoMin <- data.frame(coef2LassoMin[-1,])
colnames(coef2LassoMin) <- c("var", "coefficient")
#247 non-zero coefficients 

##method 2: simpler model with comparable error to the best - lambda.1se
c2.1se<-coef(mod2,s='lambda.1se',exact=TRUE)
c2.1se.inds<-which(c2.1se!=0)
coef2Lasso1se <- cbind(row.names(c2.1se)[c2.1se.inds], c2.1se[c2.1se.inds])
#removed the intercept row
coef2Lasso1se<- data.frame(coef2Lasso1se[-1,])
colnames(coef2Lasso1se) <- c("var", "coefficient")
#194 coefficients

mod2.min.results <- predict(mod2,testEncode_mtx, s="lambda.min")
mod2.min.results.label <- ifelse(mod2.min.results > 0.5, 1,0)
confusionMatrix(y_test$deEscInd3000, 
                as.factor(mod2.min.results.label), 
                mode="everything",
                positive = "1")
# Reference
# Prediction      0      1
# 0  32167  26737
# 1  28553 130355
# 
# Accuracy : 0.7462         
# 95% CI : (0.7443, 0.748)
# Precision : 0.8203         
# Recall : 0.8298         
# F1 : 0.8250   

mod2.1se.results <- predict(mod2,testEncode_mtx, s="lambda.1se")
mod2.1se.results.label <- ifelse(mod2.1se.results > 0.5, 1,0)
confusionMatrix(y_test$deEscInd3000, 
                as.factor(mod2.1se.results.label), 
                mode="everything", 
                positive = "1")

# Reference
# Prediction      0      1
# 0  31671  27233
# 1  28002 130906

# Accuracy : 0.7464          
# 95% CI : (0.7446, 0.7482)        
# Precision : 0.8238          
# Recall : 0.8278          
# F1 : 0.8258  

save.image("Model_Lasso.RData")


# fwrite(coefLasso1se, "coefLass1SE.csv")
# 
View(coefLasso1se %>% arrange(desc(coefficient)))


