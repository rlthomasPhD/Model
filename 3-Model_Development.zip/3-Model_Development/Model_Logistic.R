# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Build logistic model for segmentation 
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "mdscore",
          "tidyverse", 
          "lubridate", 
          "caret",
          "statmod",
          "lsr",
          "ROCR",
          "AUC"
          )

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)


set.seed(4235)

# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
setwd("//client/R$/CynthiaH/NI WC Claims")
build <- fread("WC_DeEscl_Modeldf_v2.csv")
  
# readRDS("WC_DeEscl_Data_Build.rds")

# -------------------------
# 3. Process Data
# -------------------------

# infomation not available at intake
responseCol <- build %>%
  dplyr::select(contains('Incurred'),
         starts_with('deEscInd'),
         zeroLossFlg,
         over100kFlg,
         Segment_Today,
         Claim_Status_Cde) %>%
  names()
# 
# removeCol <- c("Claim_ID",
#                "Claim_Num",
#                "Claim_System_Entry_Dte",
#                "Report_dte",
#                "Injury_Dte")
# 
# textCol <- build %>% 
#   dplyr::select(ends_with('xt')) %>% 
#   names()
# 
# codeCol <- build %>% 
#   dplyr::select(ends_with('Cde'), 
#          -Gender_Cde,
#          -Claim_Status_Cde,
#          -Jurisdiction_State_Cde) %>% 
#   names()
# 
# tempRemoveCol <- c(textCol, # will be explored in the future
#                    codeCol, # have already mapped to description
#                    "Occupation_Grp",
#                    "Account_Name")

X_train <- build %>% 
  # dplyr::select(-one_of(c(responseCol, removeCol, tempRemoveCol))) %>%
  filter(folds < 4)
X_test <- build %>% 
  # dplyr::select(-one_of(c(responseCol, removeCol, tempRemoveCol))) %>%
  filter(folds > 3)
y_train <- build %>% 
  dplyr::select(c(responseCol, "folds")) %>%
  filter(folds < 4)
y_test <-  build %>% 
  dplyr::select(c(responseCol, "folds")) %>%
  filter(folds > 3)

save(X_train, X_test, y_train, y_test, file="trainTestData.RData")
load("trainTestData.RData")

# ------------------------------------------
# 4. Logistic Regression - Main Effect Only
# ------------------------------------------

# 4.1 base line model========================================

s1 <- c("Year", "Intake_Method_Grp",
        "Claimant_Age_Qty", "Gender_Cde", "Tenure", "Avg_Wkly_Wge_Amt",      
        "Initial_Seg", "InjurytoReport", "ReporttoEntry", "PrimNOI_Grp20",
        "ScdNOI_Grp10", "PrimPOB_Grp30", "ScdPOB_Grp10", "Occur_Grp30",       
        "Prim_POB_Category_Dsc", "Scd_POB_Category_Dsc", 
        "Occupation_Grp2",  "Account_Grp2", "NAICS_Grp")

# have to use variables with grouping, otherwise not all levels exist in both train and test partitions

train_df <- cbind.data.frame(X_train, y_train %>% dplyr::select(-folds))

## null model-------------------------------
mod1.null <- glm(deEscInd3000 ~ 1, 
                 data=train_df, family = binomial(link = "logit"))

## full model-------------------------------
formula.m1.full <- as.formula(paste("deEscInd3000", paste(s1, collapse = "+"), sep = "~"))

system.time(# 355.600 
  mod1.full <- glm(formula.m1.full, 
                   data=train_df, 
                   family = binomial(link = "logit"))
)

summary(mod1.full)
# with ALL  variables
# Null deviance: 381392  on 326716  degrees of freedom
# Residual deviance: 317113  on 326517  degrees of freedom
# AIC: 317513
# 
# Number of Fisher Scoring iterations: 6

pred1.full <- predict(mod1.full,test_df, se.fit = TRUE, type = "response") 
pred1.full.label <- ifelse(pred1.full$fit > 0.5, 1,0)

confusionMatrix(as.factor(y_test$deEscInd3000), as.factor(pred1.full.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  18536  40365
# 1  12206 146705

# Accuracy : 0.7586          
# 95% CI : (0.7568, 0.7604)
# Precision : 0.9232          
# Recall : 0.7842          
# F1 : 0.8481   

auc(roc(as.factor(pred1.full$fit), as.factor(y_test$deEscInd3000)))
# 0.772986

logloss(y_test$deEscInd3000, pred1.full$fit)
# 0.4859321

##########################################################################

# ---------------------------------------------
# 4.3. Add text feaatures
# ---------------------------------------------

formula.m1.v3 <- as.formula(paste("deEscInd3000", 
                                  paste(c(s1[!(s1 %in% c("Scd_POB_Category_Dsc","Jurisdiction_State_Cde_Grp"))],
                                          "prklot_head_category",
                                          "prklot_knee",
                                          "pallet_idx",                    
                                          "pallet_lowerEx",
                                          "pallet_head_category",
                                          "pallet_lowerbck",              
                                          "pallet_handarea",
                                          "allrg_idx",
                                          "notfeelwell_idx",
                                          "szre_stroke_idx"), 
                                        collapse = "+"), sep = "~"))

system.time(# 224.234 
  mod1.v3 <- glm(formula.m1.v3, 
                 data=train_df, family = binomial(link = "logit"))
)

summary(mod1.v3)

# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 315490  on 326471  degrees of freedom
# AIC: 315982

pred1.v3 <- predict(mod1.v3,test_df, se.fit = TRUE, type = "response") 
pred1.v3.label <- ifelse(pred1.v3$fit > 0.5, 1,0)

confusionMatrix(as.factor(y_test$deEscInd3000), as.factor(pred1.v3.label), mode="everything", positive = "1")
# Reference
# Reference
# Prediction      0      1
# 0  18556  40345
# 1  12193 146718

# Accuracy : 0.7588         
# 95% CI : (0.757, 0.7606)
# Precision : 0.7843        
# Recall :0.9233           
# F1 : 0.8481     

AUC::auc(roc(as.factor(pred1.v3$fit), as.factor(y_test$deEscInd3000)))
# 0.7730837

logloss <- function(actual, predicted){
  result=-1/length(actual)*(sum((actual*log(predicted)+(1-actual)*log(1-predicted))))
  return(result)
}

logloss(y_test$deEscInd3000, pred1.v3$fit)
#0.4858566




# for (col in names(train_df)){
#   print(col)
#   print(length(unique(train_df[[col]])) == length(unique(test_df[[col]])))
#   # print(length(unique(test_df[[col]])))
# }

#based on mod1.full summary remove "Tenure",  "Scd_POB_Category_Dsc"

## Version1 model-------------------------------
formula.m1.v1 <- as.formula(paste("deEscInd3000", 
                                  paste(s1[!(s1 %in% c("Tenure", "Scd_POB_Category_Dsc"))], 
                                        collapse = "+"), sep = "~"))
system.time(# 283.35
  mod1.v1 <- glm(formula.m1.v1, 
                 data=train_df, 
                 family = binomial(link = "logit"))
)

summary(mod1.v1)

pred1.v1 <- predict(mod1.v1,test_df, se.fit = TRUE) 
pred1.v1.label <- ifelse(pred1.v1$fit > 0.5, 1,0)

# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 315491  on 326472  degrees of freedom
# AIC: 315981
# 
# Number of Fisher Scoring iterations: 6

confusionMatrix(y_test$deEscInd3000, as.factor(pred1.v1.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  32219  26685
# 1  28576 130332

# Accuracy : 0.7463          
# 95% CI : (0.7445, 0.7481)
# Precision : 0.8202          
# Recall : 0.8301          
# F1 : 0.8251          

auc(roc(as.factor(pred1.v1.label), y_test$deEscInd3000))
# 0.6835737

## Version2 model-------------------------------
formula.m1.v2 <- as.formula(paste("deEscInd3000", 
                                  paste(s1[s1 !="Scd_POB_Category_Dsc"], 
                                        collapse = "+"), sep = "~"))

system.time(# 283.35
  mod1.v2 <- glm(formula.m1.v2, 
                 data=train_df, family = binomial(link = "logit"))
)

summary(mod1.v2)

# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 315490  on 326471  degrees of freedom
# AIC: 315982

pred1.v2 <- predict(mod1.v2,test_df, se.fit = TRUE) 
pred1.v2.label <- ifelse(pred1.v2$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred1.v2.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  32218  26686
# 1  28581 130327
# 
# Accuracy : 0.7463          
# 95% CI : (0.7444, 0.7481)
# Precision : 0.8201          
# Recall : 0.8300          
# F1 : 0.8251 

auc(roc(as.factor(pred1.v2.label), y_test$deEscInd3000))
# 0.6835495

# compare model
lr.test(mod1.v1, mod1.full)
lr.test(mod1.v2, mod1.full)

# system.time( #5059.739
#   mod1.AIC <-  step(mod1.v1, 
#                     direction = "both",  
#                     scope = list(lower = ~1, upper = ~. ),
#                     data = train_df %>% select(-Tenure, -Scd_POB_Category_Dsc),
#                     trace = FALSE)
# )

# summary(mod1.AIC) #this is the same as mod1.v1
# 
# length(mod1.AIC$coefficients)
# length(mod1.v1$coefficients)

# Signif. codes:  0 â***â 0.001 â**â 0.01 â*â 0.05 â.â 0.1 â â 1
# 
# (Dispersion parameter for binomial family taken to be 1)
# 
# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 294043  on 326471  degrees of freedom
# AIC: 294535

# test correlation ============================================
# tbl <- table(train$Primary_Part_Of_Body_Cde, train$Occurrence_Cde)
# chiVal <- chisq.test(tbl, simulate.p.value = TRUE)
# c(chiVal$statistic, chiVal$p.value)
# # X-squared              
# # 1.547673e+06 4.997501e-04 
# cramersV(tbl, simulate.p.value = TRUE)
# # 0.2294205
# ==============================================================

save(mod1.full, mod1.null, mod1.v1, mod1.v2, file = "BaslineLogMod.RData")

# refine grouping---------------------------------------

X_train <- X_train %>% mutate(PrimNOI_Grp_v1 = ifelse(Prim_NOI_Dsc %in% c("Laceration", 
                                                               "Strain",
                                                               "Contusion",
                                                               "Inflammation",
                                                               "Crushing",
                                                               "Sprain",
                                                               "Injury"),
                                                     Prim_NOI_Dsc, as.character(PrimNOI_km_11c))) %>%
                      mutate(PrimNOI_Grp_v1 = if_else(PrimNOI_Grp_v1 %in% c("4", "6"), "2", PrimNOI_Grp_v1)) %>%
                      mutate(Occur_Grp_v1 = if_else(Occur_Dsc %in% c("Strain or injury by repetitive motion",
                                                                     "strain or injury by not otherwise specified",
                                                                     "Injury from Falling or flying object",
                                                                     "Cumulative, not otherwise classified",
                                                                     "Miscellaneous",
                                                                     "other than physical cause of injury"),
                                                    Occur_Dsc, if_else(Occur_pam_6c %in% c("5", "6"), Occur_pam_6c,
                                                                            if_else(Occur_km_6c %in% c("2", "4"), Occur_km_6c,
                                                                                    if_else(Occur_km_6c == "3", "4", "1"))))) %>%
                      mutate(PrimPOB_Grp_v1 = ifelse(Prim_POB_Dsc %in% c("Chest, ribs or sternum", 
                                                                         "Eye(s)",
                                                                         "Finger(s)",
                                                                         "Hand",
                                                                         "Heart",
                                                                         "Knee",
                                                                         "Thumb",
                                                                         "Toe(s)",
                                                                         "Upper back (thoracic area)",
                                                                         "Wrist",
                                                                         "Elbow",
                                                                         "Head",
                                                                         "Hip",
                                                                         "Insufficient Information",
                                                                         "Lower leg",
                                                                         "Lungs",
                                                                         "Shoulder",
                                                                         "Multiple body parts"),
                                                     Prim_POB_Dsc, 
                                                     if_else(PrimPOB_pam_4c == "1", "1",
                                                             ifelse(PrimPOB_km_3c == "1", "2", "3")))) 


                      

X_test <- X_test %>% 
            mutate(PrimNOI_Grp_v1 = ifelse(Prim_NOI_Dsc %in% c("Laceration", 
                                                                "Strain",
                                                                "Contusion",
                                                                "Inflammation",
                                                                "Crushing",
                                                                "Sprain",
                                                                "Injury"),
                                            Prim_NOI_Dsc, as.character(PrimNOI_km_11c))) %>%
            mutate(PrimNOI_Grp_v1 = if_else(PrimNOI_Grp_v1 %in% c("4", "6"), "2", PrimNOI_Grp_v1)) %>%
            mutate(Occur_Grp_v1 = if_else(Occur_Dsc %in% c("Strain or injury by repetitive motion",
                                                           "strain or injury by not otherwise specified",
                                                           "Injury from Falling or flying object",
                                                           "Cumulative, not otherwise classified",
                                                           "Miscellaneous",
                                                           "other than physical cause of injury"),
                                          Occur_Dsc, if_else(Occur_pam_6c %in% c("5", "6"), Occur_pam_6c,
                                                             if_else(Occur_km_6c %in% c("2", "4"), Occur_km_6c,
                                                                     if_else(Occur_km_6c == "3", "4", "1"))))) %>%
            mutate(PrimPOB_Grp_v1 = ifelse(Prim_POB_Dsc %in% c("Chest, ribs or sternum", 
                                                               "Eye(s)",
                                                               "Finger(s)",
                                                               "Hand",
                                                               "Heart",
                                                               "Knee",
                                                               "Thumb",
                                                               "Toe(s)",
                                                               "Upper back (thoracic area)",
                                                               "Wrist",
                                                               "Elbow",
                                                               "Head",
                                                               "Hip",
                                                               "Insufficient Information",
                                                               "Lower leg",
                                                               "Lungs",
                                                               "Shoulder",
                                                               "Multiple body parts"),
                                           Prim_POB_Dsc, 
                                           if_else(PrimPOB_pam_4c == "1", "1",
                                                   ifelse(PrimPOB_km_3c == "1", "2", "3"))))

  

s2 <- c("Year", 
        "Jurisdiction_State_Cde_Grp", 
        "Intake_Method_Grp",
        "Claimant_Age_Qty", 
        "Gender_Cde", 
        "Tenure", 
        "Avg_Wkly_Wge_Amt",      
        "Initial_Seg", 
        "InjurytoReport", 
        "ReporttoEntry", 
        "PrimNOI_Grp_v1",
        "ScdNOI_Grp10", 
        "PrimPOB_Grp30", #tried PrimPOB_Grp_v1 but does not improve model performance
        "ScdPOB_Grp10", 
        "Occur_Grp_v1",       
        "Prim_POB_Category_Dsc", 
        "Occupation_Grp2",
        "Account_Grp2",
        "NAICS_Grp")

train_df <- cbind.data.frame(X_train, y_train %>% dplyr::select(-folds))
test_df <- cbind.data.frame(X_test, y_test %>% dplyr::select(-folds))

formula.m2.v1 <- as.formula(paste("deEscInd3000", paste(s2, collapse = "+"), sep = "~"))

system.time(# 228.813 RGrid 297.71 VM
  mod2.v1 <- glm(formula.m2.v1, 
                 data=train_df, 
                 family = binomial(link = "logit"))
)

summary(mod2.v1)

# Residual deviance: 314777  on 326496  degrees of freedom
# AIC: 315219
# 
# Number of Fisher Scoring iterations: 6


pred2.v1 <- predict(mod2.v1,X_test, se.fit = TRUE) 
pred2.v1.label <- ifelse(pred2.v1$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred2.v1.label), mode="everything")
# Reference
# Prediction      0      1
# 0  32221  26682
# 1  28251 130657
# Accuracy : 0.7478
# 95% CI : (0.746, 0.7496)
# 
# Precision : 0.5470
# Recall : 0.5328
# F1 : 0.5398

AUC::auc(roc(as.factor(pred2.v1.label), y_test$deEscInd3000))
# 0.6846233

#==============================================================================

# use lasso to remove unsignificant levels ---------------------------------------

EncodeCol <- c("Year", 
               "Jurisdiction_State_Cde_Grp", 
               "Intake_Method_Grp",
               "Gender_Cde", 
               "Avg_Wkly_Wge_Amt",      
               "Initial_Seg", 
               "InjurytoReport", 
               "ReporttoEntry", 
               "PrimNOI_Grp_v1",
               "ScdNOI_Grp10", 
               "PrimPOB_Grp30", #tried PrimPOB_Grp_v1 but does not improve model performance
               "ScdPOB_Grp10", 
               "Occur_Grp_v1",       
               "Prim_POB_Category_Dsc", 
               "Occupation_Grp2",
               "Account_Grp2",
               "NAICS_Grp")

dmyTrain <- dummyVars(" ~ .", data = X_train %>% select(EncodeCol))
trainCatEncode <- data.frame(predict(dmyTrain, newdata = X_train %>% select(EncodeCol)))
trainEncode_df <- cbind(train_df %>% select(-one_of(EncodeCol)), trainCatEncode)
trainEncode_mtx <- model.matrix( ~ ., trainEncode_df %>% select(-deEscInd3000))

dmyTest <- dummyVars(" ~ .", data = X_test %>% select(EncodeCol))
testCatEncode <- data.frame(predict(dmyTest, newdata = X_test %>% select(EncodeCol)))
testEncode_df <- cbind(test_df %>% select(-one_of(EncodeCol)), testCatEncode)
testEncode_mtx <- model.matrix( ~ ., testEncode_df %>% select(-deEscInd3000))

# ---------------------------------------------
# 4.3. Add text feaatures
# ---------------------------------------------

formula.m1.v3 <- as.formula(paste("deEscInd3000", 
                                  paste(c(s1[!(s1 %in% c("Scd_POB_Category_Dsc","Jurisdiction_State_Cde_Grp"))],
                                          "prklot_head_category",
                                          "prklot_knee",
                                          "pallet_idx",                    
                                          "pallet_lowerEx",
                                          "pallet_head_category",
                                          "pallet_lowerbck",              
                                          "pallet_handarea",
                                          "allrg_idx",
                                          "notfeelwell_idx",
                                          "szre_stroke_idx"), 
                                        collapse = "+"), sep = "~"))

system.time(# 224.234 
  mod1.v3 <- glm(formula.m1.v3, 
                 data=train_df, family = binomial(link = "logit"))
)

summary(mod1.v3)

# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 315490  on 326471  degrees of freedom
# AIC: 315982

pred1.v3 <- predict(mod1.v3,test_df, se.fit = TRUE, type = "response") 
pred1.v3.label <- ifelse(pred1.v3$fit > 0.5, 1,0)

confusionMatrix(as.factor(y_test$deEscInd3000), as.factor(pred1.v3.label), mode="everything", positive = "1")
# Reference
# Reference
# Prediction      0      1
# 0  18556  40345
# 1  12193 146718

# Accuracy : 0.7588         
# 95% CI : (0.757, 0.7606)
# Precision : 0.9233         
# Recall : 0.7843         
# F1 : 0.8481     

AUC::auc(roc(as.factor(pred1.v3$fit), as.factor(y_test$deEscInd3000)))
# 0.7730837

logloss <- function(actual, predicted){
  result=-1/length(actual)*(sum((actual*log(predicted)+(1-actual)*log(1-predicted))))
  return(result)
}

logloss(y_test$deEscInd3000, pred1.v3$fit)
#0.4858566




# ---------------------------------------------
# 5. Logistic Regression - Two-way Interaction
# ---------------------------------------------

interact <- c("Claimant_Age_Qty:Gender_Cde",
              "Avg_Wkly_Wge_Amt:PrimNOI_Grp_v1",
              "Claimant_Age_Qty:PrimNOI_Grp_v1", 
              "Claimant_Age_Qty:Prim_POB_Category_Dsc",
              "Claimant_Age_Qty:Occur_Grp_v1",
              "PrimNOI_Grp_v1:ScdNOI_Grp10",
              "Occur_Grp_v1:Prim_POB_Category_Dsc",
              "PrimNOI_Grp_v1:Prim_POB_Category_Dsc",
              "Occupation_Grp2:PrimNOI_Grp_v1")
s3 <- c(s2, interact)

formula.m3.v1 <- as.formula(paste("deEscInd3000", paste(s3, collapse = "+"), sep = "~"))

system.time(# 19640.78 VM
  mod3.v1 <- glm(formula.m3.v1, 
                 data=train_df, 
                 family = binomial(link = "logit"))
)

summary.mod3.v1 <- summary(mod3.v1)
fwrite(as.data.frame.matrix(summary.mod3.v1$coefficients), file = "logistic_mod3_v1s1d1.csv", row.names = TRUE)

pred3.v1 <- predict(mod3.v1,X_test, se.fit = TRUE) 
pred3.v1.label <- ifelse(pred3.v1$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred3.v1.label), mode="everything")



c("Year", 
  "Jurisdiction_State_Cde_Grp", 
  "Intake_Method_Grp",
  "Claimant_Age_Qty", 
  "Gender_Cde", 
  "Tenure", 
  "Avg_Wkly_Wge_Amt",      
  "Initial_Seg", 
  "InjurytoReport", 
  "ReporttoEntry", 
  "PrimNOI_Grp_v1",
  "ScdNOI_Grp10", 
  "PrimPOB_Grp30", #tried PrimPOB_Grp_v1 but does not improve model performance
  "ScdPOB_Grp10", 
  "Occur_Grp_v1",       
  "Prim_POB_Category_Dsc", 
  "Occupation_Grp2",
  "Account_Grp2",
  "NAICS_Grp")

system.time(# 339.795
  mod2.v1 <- glm(deEscInd3000 ~ . + Claimant_Age_Qty:PrimNOI_Grp20, 
                 data=train_df %>% select(-Tenure, -Scd_POB_Category_Dsc), family = binomial(link = "logit"))
)

summary(mod2.v1)


pred2.v1 <- predict(mod2.v1,test_df, se.fit = TRUE) 
pred2.v1.label <- ifelse(pred2.v1$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred2.v1.label), mode="everything")
# Accuracy : 0.7699  
# Precision : 0.5434          
# Recall : 0.5796    

# accuracy improvement is VERY MINIMAL!


system.time(# 
  mod2.v2 <- glm(deEscInd3000 ~ . + Claimant_Age_Qty:PrimNOI_Grp20 + Occur_Grp30:PrimPOB_Grp30, 
                 data=train_df %>% select(-Tenure, -Scd_POB_Category_Dsc), family = binomial(link = "logit"))
)







# ---------------------------------------------
# 6. Logistic Regression - Three-way Interaction
# ---------------------------------------------




