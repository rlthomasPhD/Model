# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Refit logistic model without using jurisdiction states 
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "mdscore",
          "tidyverse", 
          "lubridate", 
          "caret",
          "statmod",
          "lsr",
          "ROCR",
          "AUC",
          "glmnet"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

set.seed(4235)

logloss <- function(actual, predicted){
  result=-1/length(actual)*(sum((actual*log(predicted)+(1-actual)*log(1-predicted))))
  return(result)
}

# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
setwd("//client/R$/CynthiaH/NI WC Claims")
load("trainTestData.RData")

# -------------------------
# 3. Process Data
# -------------------------
# refine grouping
X_train <- X_train %>% 
             mutate(PrimNOI_Grp_v1 = ifelse(Prim_NOI_Dsc %in% c("Laceration", 
                                                                "Strain",
                                                                "Contusion",
                                                                "Inflammation",
                                                                "Crushing",
                                                                "Sprain",
                                                                "Injury"),
                                            Prim_NOI_Dsc, as.character(PrimNOI_km_11c))) %>%
              mutate(PrimNOI_Grp_v1 = if_else(PrimNOI_Grp_v1 %in% c("4", "6"), "2", PrimNOI_Grp_v1)) %>%
              mutate(Occur_Grp_v1 = if_else(Occur_Dsc %in% c("Strain or injury by repetitive motion",
                                                             "strain or injury by not otherwise specified",
                                                             "Injury from Falling or flying object",
                                                             "Cumulative, not otherwise classified",
                                                             "Miscellaneous",
                                                             "other than physical cause of injury"),
                                            Occur_Dsc, if_else(Occur_pam_6c %in% c("5", "6"), Occur_pam_6c,
                                                               if_else(Occur_km_6c %in% c("2", "4"), Occur_km_6c,
                                                                       if_else(Occur_km_6c == "3", "4", "1"))))) %>%
              mutate(PrimPOB_Grp_v1 = ifelse(Prim_POB_Dsc %in% c("Chest, ribs or sternum", 
                                                                 "Eye(s)",
                                                                 "Finger(s)",
                                                                 "Hand",
                                                                 "Heart",
                                                                 "Knee",
                                                                 "Thumb",
                                                                 "Toe(s)",
                                                                 "Upper back (thoracic area)",
                                                                 "Wrist",
                                                                 "Elbow",
                                                                 "Head",
                                                                 "Hip",
                                                                 "Insufficient Information",
                                                                 "Lower leg",
                                                                 "Lungs",
                                                                 "Shoulder",
                                                                 "Multiple body parts"),
                                             Prim_POB_Dsc, 
                                             if_else(PrimPOB_pam_4c == "1", "1",
                                                     ifelse(PrimPOB_km_3c == "1", "2", "3")))) 

X_test <- X_test %>% 
            mutate(PrimNOI_Grp_v1 = ifelse(Prim_NOI_Dsc %in% c("Laceration", 
                                                               "Strain",
                                                               "Contusion",
                                                               "Inflammation",
                                                               "Crushing",
                                                               "Sprain",
                                                               "Injury"),
                                           Prim_NOI_Dsc, as.character(PrimNOI_km_11c))) %>%
            mutate(PrimNOI_Grp_v1 = if_else(PrimNOI_Grp_v1 %in% c("4", "6"), "2", PrimNOI_Grp_v1)) %>%
            mutate(Occur_Grp_v1 = if_else(Occur_Dsc %in% c("Strain or injury by repetitive motion",
                                                           "strain or injury by not otherwise specified",
                                                           "Injury from Falling or flying object",
                                                           "Cumulative, not otherwise classified",
                                                           "Miscellaneous",
                                                           "other than physical cause of injury"),
                                          Occur_Dsc, if_else(Occur_pam_6c %in% c("5", "6"), Occur_pam_6c,
                                                             if_else(Occur_km_6c %in% c("2", "4"), Occur_km_6c,
                                                                     if_else(Occur_km_6c == "3", "4", "1"))))) %>%
            mutate(PrimPOB_Grp_v1 = ifelse(Prim_POB_Dsc %in% c("Chest, ribs or sternum", 
                                                               "Eye(s)",
                                                               "Finger(s)",
                                                               "Hand",
                                                               "Heart",
                                                               "Knee",
                                                               "Thumb",
                                                               "Toe(s)",
                                                               "Upper back (thoracic area)",
                                                               "Wrist",
                                                               "Elbow",
                                                               "Head",
                                                               "Hip",
                                                               "Insufficient Information",
                                                               "Lower leg",
                                                               "Lungs",
                                                               "Shoulder",
                                                               "Multiple body parts"),
                                           Prim_POB_Dsc, 
                                           if_else(PrimPOB_pam_4c == "1", "1",
                                                   ifelse(PrimPOB_km_3c == "1", "2", "3"))))

train_df <- cbind.data.frame(X_train, y_train %>% dplyr::select(-folds))
test_df <- cbind.data.frame(X_test, y_test %>% dplyr::select(-folds))

# ------------------------------------------
# 4. Logistic Regression - Main Effect Only
# ------------------------------------------

# 4.1 base line model========================================

s3 <- c("Year", 
        "Intake_Method_Grp",
        "Claimant_Age_Qty", 
        "Gender_Cde", 
        "Tenure", 
        "Avg_Wkly_Wge_Amt",      
        "Initial_Seg", 
        "InjurytoReport", 
        "ReporttoEntry", 
        "PrimNOI_Grp_v1",
        "ScdNOI_Grp10", 
        "PrimPOB_Grp30", 
        "ScdPOB_Grp10", 
        "Occur_Grp_v1",       
        "Prim_POB_Category_Dsc", 
        "Scd_POB_Category_Dsc", 
        "Occupation_Grp2",
        "Account_Grp2",
        "NAICS_Grp")

## null model-------------------------------
mod3.null <- glm(deEscInd3000 ~ 1, 
                 data=train_df, family = binomial(link = "logit"))


## full model-------------------------------
formula.m3.full <- as.formula(paste("deEscInd3000", paste(s3, collapse = "+"), sep = "~"))

system.time(# 209.031
  mod3.full <- glm(formula.m3.full, 
                   data=train_df, 
                   family = binomial(link = "logit"))
)

summary(mod3.full)
# with ALL  variables
# Null deviance: 381440  on 326717  degrees of freedom
# Residual deviance: 316887  on 326540  degrees of freedom
# AIC: 317243
# Number of Fisher Scoring iterations: 6

pred3.full <- predict(mod3.full,test_df, se.fit = TRUE, type = "response") 
pred3.full.label <- ifelse(pred3.full$fit > 0.5, 1, 0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred3.full.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  18888  40027
# 1  12211 146685

# Accuracy : 0.7602         
# 95% CI : (0.7584, 0.762)
# Precision : 0.9232         
# Recall : 0.7856         
# F1 : 0.8489    

AUC::auc(roc(as.factor(pred3.full$fit), y_test$deEscInd3000))
# 0.7737459

logloss(as.numeric(as.character(y_test$deEscInd3000)), pred3.full$fit)
# 0.4850066

## Version1 model-------------------------------
formula.m3.v1 <- as.formula(paste("deEscInd3000", 
                                  paste(s3[!(s3 %in% c("Scd_POB_Category_Dsc"))], 
                                        collapse = "+"), sep = "~"))
system.time(# 283.35
  mod3.v1 <- glm(formula.m3.v1, 
                 data=train_df, 
                 family = binomial(link = "logit"))
)

summary(mod3.v1)
# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 316903  on 326546  degrees of freedom
# AIC: 317247
# 
# Number of Fisher Scoring iterations: 6

pred3.v1 <- predict(mod3.v1,test_df, se.fit = TRUE, type = "response") 
pred3.v1.label <- ifelse(pred3.v1$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred3.v1.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  18882  40033
# 1  12204 146692
# 
# Accuracy : 0.7602         
# 95% CI : (0.7584, 0.762)
# Precision : 0.9232         
# Recall : 0.7856         
# F1 : 0.8489             

AUC::auc(roc(as.factor(pred3.v1$fit), y_test$deEscInd3000))
#  0.7737227

logloss(as.numeric(as.character(y_test$deEscInd3000)), pred3.v1$fit)
# 0.4850231

# likelihood ratio test
lr.test(mod3.v1, mod3.full) 

### p < 5% based on prediction performance and goodness of fit the full model is better 

### >>>>>>>>>>>>>>>>>>>>>>mod3.full better >>>>>>>>>>>>>>>>>>>>>>>>>>>>  

## Version2 model-------------------------------

# combine the Prim_POB_Category_Dsc and PrimPOB_Grp30
# combine the Scd_POB_Category_Dsc and ScdPOB_Grp30

# data process
train_df <- train_df %>% mutate(PrimPOB_Grp_cmb = ifelse(PrimPOB_Grp30 == "OTHER_GRP", 
                                                         paste0("Oth_", Prim_POB_Category_Dsc), PrimPOB_Grp30),
                                ScdPOB_Grp_cmb = ifelse(ScdPOB_Grp10 == "OTHER_GRP", 
                                                         paste0("Oth_", Scd_POB_Category_Dsc), ScdPOB_Grp10))
test_df <- test_df %>% mutate(PrimPOB_Grp_cmb = ifelse(PrimPOB_Grp30 == "OTHER_GRP", 
                                                         paste0("Oth_", Prim_POB_Category_Dsc), PrimPOB_Grp30),
                              ScdPOB_Grp_cmb = ifelse(ScdPOB_Grp10 == "OTHER_GRP", 
                                                      paste0("Oth_", Scd_POB_Category_Dsc), ScdPOB_Grp10))

formula.m3.v2 <- as.formula(paste("deEscInd3000", 
                                  paste(c(s3[!(s3 %in% c("Scd_POB_Category_Dsc", 
                                                         "ScdPOB_Grp10",
                                                         "Prim_POB_Category_Dsc",
                                                         "PrimPOB_Grp30"))],
                                          c("ScdPOB_Grp_cmb",
                                            "PrimPOB_Grp_cmb")), 
                                        collapse = "+"), sep = "~"))

system.time(# 283.35
  mod3.v2 <- glm(formula.m3.v2, 
                 data=train_df, family = binomial(link = "logit"))
)

summary(mod3.v2)
# Null deviance: 381402  on 326716  degrees of freedom
# Residual deviance: 316887  on 326540  degrees of freedom
# AIC: 317243

pred3.v2 <- predict(mod3.v2,test_df, se.fit = TRUE, type = "response") 
pred3.v2.label <- ifelse(pred3.v2$fit > 0.5, 1,0)

confusionMatrix(y_test$deEscInd3000, as.factor(pred3.v2.label), mode="everything", positive = "1")
# Reference
# Prediction      0      1
# 0  18888  40027
# 1  12211 146685

# Accuracy : 0.7602         
# 95% CI : (0.7584, 0.762)
# Precision : 0.9232         
# Recall : 0.7856         
# F1 : 0.8489     

AUC::auc(roc(as.factor(pred3.v2$fit), y_test$deEscInd3000))
# 0.7737227

logloss(as.numeric(as.character(y_test$deEscInd3000)), pred3.v2$fit)
# 0.4850231

### >>>>>>>>>>>>>>>>>>>>>>mod3.v2 is more interpretable, same performance as mod3.full >>>>>>>>>>>>>>>>>>>>>>>>>>>>  

## Version3 model-------------------------------

formula.m3.test <- as.formula(paste("deEscInd3000", 
                                  paste(s3[!(s3 %in% c("NAICS_Grp"))], 
                                        collapse = "+"), sep = "~"))
system.time(# 283.35
  mod3.test <- glm(formula.m3.test, 
                 data=train_df, 
                 family = binomial(link = "logit"))
)



# improve NAIC grouping

lr.test(mod3.v2, mod3.v1)
lr.test(mod3.test, mod3.full)
lr.test(mod3.v1, mod3.full)

11      21      22      23      31      32      33      42      44      45      48      49      51      52      53      54 
1175    2968    1651    9929   10871   20800   14880    9657   39807   16691    8031    5389   13320    5839    5497    4599 
55      56      61      62      71      72      81      92 missing 
446   17614    4991   11045    6182   17818    3411     908   93199 

##########################################################################################################

# ------------------------------------------
# 4. Logistic Regression - Interaction
# ------------------------------------------

maineff <- c("Year",
             "Intake_Method_Grp",
             "Claimant_Age_Qty", 
             "Gender_Cde", 
             "Tenure", 
             "Avg_Wkly_Wge_Amt",      
             "Initial_Seg", 
             "InjurytoReport", 
             "ReporttoEntry", 
             "PrimNOI_Grp_v1",
             "ScdNOI_Grp10", 
             "ScdPOB_Grp_cmb",
             "PrimPOB_Grp_cmb",
             "Occur_Grp_v1",       
             "Occupation_Grp2",
             "Account_Grp2",
             "NAICS_Grp")

inter_list <- c("Initial_Seg", "PrimNOI_Grp_v1", "PrimPOB_Grp_cmb")


inter_list1 <- inter_list
# Exhaustive search
for (var1 in inter_list){
  inter_list2 <- inter_list1[inter_list1 != var1]
  result <- data.frame()
  if(length(inter_list2)>0){
    for (var2 in inter_list2){
      inter_term <- paste0(var1, ":", var2)
      start_time <- Sys.time()
      
      formula.m3.test <- as.formula(paste("deEscInd3000", 
                                          paste(c(maineff, inter_term), 
                                                collapse = "+"), sep = "~"))
      
      print(formula.m3.test)
      print(inter_term)
    
      mod3.test <- glm(formula.m3.test,
                       data=train_df,
                       family = binomial(link = "logit"))

      summary <- summary(mod3.test)
      res.dev <- summary[["deviance"]]
      aic <- summary[["aic"]]

      pred3.test <- predict(mod3.test,test_df, se.fit = TRUE, type = "response")
      pred3.test.label <- ifelse(pred3.test$fit > 0.5, 1,0)

      metrics <- confusionMatrix(y_test$deEscInd3000, as.factor(pred3.test.label),
                                 mode="everything", positive = "1")

      confusion_tbl <- as.data.frame(t(c(metrics[["table"]][1,], metrics[["table"]][2,])))
      names(confusion_tbl) <- c("TN", "FN", "FP", "TP")
      metrics_df <- as.data.frame(t(c(metrics[["overall"]],metrics[["byClass"]])))

      mod.auc <- AUC::auc(roc(as.factor(pred3.v2$fit), y_test$deEscInd3000))
      mod.logloss <- logloss(as.numeric(as.character(y_test$deEscInd3000)), pred3.test$fit)

      mod.result <- cbind(cbind(data.frame(interaction = inter_term,
                           resid_dev = res.dev,
                           AIC = aic,
                           AUC = mod.auc,
                           Logloss = mod.logloss),
                      confusion_tbl),
                      metrics_df)

      inter_list1 <-inter_list2
      
      end_time <- Sys.time()
      print(end_time- start_time)
      result <- rbind(result, mod.result)
    }
  } 
}

fwrite(result, file="mod_log_interaction.csv")


# Search by prespecificed

  for (inter_term in inter_term_list){
    
    formula.m3.test <- as.formula(paste("deEscInd3000", 
                                        paste(c(maineff, inter_term), 
                                              collapse = "+"), sep = "~"))
    
    print(formula.m3.test )
    print(inter_term)
    
    mod3.test <- glm(formula.m3.test,
                     data=train_df,
                     family = binomial(link = "logit"))
    
    summary <- summary(mod3.test)
    res.dev <- summary[["deviance"]]
    aic <- summary[["aic"]]
    
    pred3.test <- predict(mod3.test,test_df, se.fit = TRUE, type = "response")
    pred3.test.label <- ifelse(pred3.test$fit > 0.5, 1,0)
    
    metrics <- confusionMatrix(y_test$deEscInd3000, as.factor(pred3.test.label),
                               mode="everything", positive = "1")
    
    confusion_tbl <- as.data.frame(t(c(metrics[["table"]][1,], metrics[["table"]][2,])))
    names(confusion_tbl) <- c("TN", "FN", "FP", "TP")
    metrics_df <- as.data.frame(t(c(metrics[["overall"]],metrics[["byClass"]])))
    
    mod.auc <- AUC::auc(roc(as.factor(pred3.v2$fit), y_test$deEscInd3000))
    mod.logloss <- logloss(as.numeric(as.character(y_test$deEscInd3000)), pred3.test$fit)
    
    mod.result <- cbind(cbind(data.frame(interaction = inter_term,
                                         resid_dev = res.dev,
                                         AIC = aic,
                                         AUC = mod.auc,
                                         Logloss = mod.logloss),
                              confusion_tbl),
                        metrics_df)
    
    inter_list1 <-inter_list2
    
    end_time <- Sys.time()
    print(end_time- start_time)
    result <- rbind(result, mod.result)
  }
} 
}


Initial_Seg:Intake_Method_Grp 
Initial_Seg:Claimant_Age_Qty
Initial_Seg:Gender_Cde
Initial_Seg:Tenure
Initial_Seg:Avg_Wkly_Wge_Amt
Initial_Seg:InjurytoReport
Initial_Seg:ReporttoEntry
Initial_Seg:PrimNOI_Grp_v1
Initial_Seg:Occur_Grp_v1
Initial_Seg:Occur_Grp_v1
Initial_Seg:Occupation_Grp2
Initial_Seg:Account_Grp2
Initial_Seg:NAICS_Grp
Initial_Seg:PrimPOB_Grp_cmb


Claimant_Age_Qty:Claimant_Age_Qty
Claimant_Age_Qty:Tenure
Claimant_Age_Qty:Avg_Wkly_Wge_Amt
Claimant_Age_Qty:InjurytoReport
Claimant_Age_Qty:ReporttoEntry
Claimant_Age_Qty:PrimNOI_Grp_v1
Claimant_Age_Qty:ScdNOI_Grp10
Claimant_Age_Qty:Occur_Grp_v1
Claimant_Age_Qty:Occupation_Grp2
Claimant_Age_Qty:Account_Grp2
Claimant_Age_Qty:NAICS_Grp
Claimant_Age_Qty:ScdPOB_Grp_cmb
Claimant_Age_Qty:PrimPOB_Grp_cmb



Gender_Cde:Claimant_Age_Qty
Gender_Cde:Tenure
Gender_Cde:Avg_Wkly_Wge_Amt
Gender_Cde:InjurytoReport
Gender_Cde:ReporttoEntry
Gender_Cde:PrimNOI_Grp_v1
Gender_Cde:ScdNOI_Grp10
Gender_Cde:Occur_Grp_v1
Gender_Cde:Occupation_Grp2
Gender_Cde:Account_Grp2
Gender_Cde:NAICS_Grp
Gender_Cde:ScdPOB_Grp_cmb
Gender_Cde:PrimPOB_Grp_cmb




Intake_Method_Grp + Claimant_Age_Qty + 
  Gender_Cde + Tenure + Avg_Wkly_Wge_Amt + Initial_Seg + InjurytoReport + 
  ReporttoEntry + PrimNOI_Grp_v1 + ScdNOI_Grp10 + Occur_Grp_v1 + 
  Occupation_Grp2 + Account_Grp2 + NAICS_Grp + ScdPOB_Grp_cmb + 
  PrimPOB_Grp_cmb






