# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Build logistic model for segmentation 
# ===========================================================================================

# -------------------------
# 1. Preambles
# -------------------------

libs <- c("data.table", 
          "tidyverse", 
          "lubridate", 
          "caret",
          "statmod",
          "lsr",
          "ROCR",
          "AUC",
          "xgboost",
          "Matrix",
          "mlr")

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

set.seed(4235)

# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
# setwd("//client/R$/CynthiaH/NI WC Claims")

load("trainTestData.RData" )

# -------------------------
# 3. Process Data
# -------------------------

# check categorical var levels in train and test
colnames <- names(X_train)
for(col in colnames){
  if(is.character(X_train[[col]])){
    train_level <- length(unique(X_train[[col]]))
    test_level <- length(unique(X_test[[col]]))
    
    if(train_level != test_level){
      print(col)
      print(paste("train:", train_level))
      print(paste("test:", test_level))
      
      print(setdiff(unique(X_train[[col]]), 
                      unique(X_test[[col]])))
      print(setdiff(unique(X_test[[col]]), 
                    unique(X_train[[col]])))

      cat("\n")
    }
  }
}

# [1] "Jurisdiction_State_Cde"
# [1] "Prim_NOI_Dsc"
# [1] "Scd_NOI_Dsc"

# group the levels with really low frequence in "Prim_NOI_Dsc" and "Scd_NOI_Dsc"
prim_NOI_grp_lvl <- rbind(X_train, X_test) %>% 
                    group_by(Prim_NOI_Dsc) %>% 
                    tally() %>%
                    arrange(n) %>% 
                    filter(n < 20) %>%
                    pull(Prim_NOI_Dsc)

scd_NOI_grp_lvl <- rbind(X_train, X_test) %>% 
                    group_by(Scd_NOI_Dsc) %>% 
                    tally() %>%
                    arrange(n) %>% 
                    filter(n < 50) %>%
                    pull(Scd_NOI_Dsc)

X_train <- X_train %>% 
            mutate(Prim_NOI_Dsc_Grp = if_else(Prim_NOI_Dsc %in% prim_NOI_grp_lvl, "Other", Prim_NOI_Dsc),
                   Scd_NOI_Dsc_Grp = if_else(Scd_NOI_Dsc %in% scd_NOI_grp_lvl, "Other", Scd_NOI_Dsc),
                   PrimNOI_km_11c = as.character(PrimNOI_km_11c),
                   PrimNOI_pam_11c = as.character(PrimNOI_pam_11c))

X_test <- X_test  %>% 
          mutate(Prim_NOI_Dsc_Grp = if_else(Prim_NOI_Dsc %in% prim_NOI_grp_lvl, "Other", Prim_NOI_Dsc),
                 Scd_NOI_Dsc_Grp = if_else(Scd_NOI_Dsc %in% scd_NOI_grp_lvl, "Other", Scd_NOI_Dsc),
                 PrimNOI_km_11c = as.character(PrimNOI_km_11c),
                 PrimNOI_pam_11c = as.character(PrimNOI_pam_11c))
  

# prepare training set----------------------------
# matrix format
X_train_dmy <- dummyVars(" ~ .", 
                         data = X_train %>% 
                                select(-Jurisdiction_State_Cde, 
                                       -Intake_Method_Grp,
                                       -folds,
                                       -Prim_NOI_Dsc,
                                       -Scd_NOI_Dsc)) 
                          # these two fields are too similar as the ungrouped field
X_train_encode <- predict(X_train_dmy, 
                          newdata = X_train %>% 
                                    select(-Jurisdiction_State_Cde, 
                                           -Intake_Method_Grp,
                                           -folds,
                                           -Prim_NOI_Dsc,
                                           -Scd_NOI_Dsc))
train_mtx <- xgb.DMatrix(data = as(X_train_encode, "dgCMatrix"), 
                         label = as.numeric(as.character(y_train$deEscInd3000)))
# data frame format
train_df <- as.data.frame(cbind(X_train_encode, y_train["deEscInd3000"]))
names(train_df) <- make.names(names(train_df), unique = TRUE)

# prepare testing set------------------------------
# matrix format
X_test_dmy <- dummyVars(" ~ .", 
                        data = X_test %>% 
                                select(-Jurisdiction_State_Cde, 
                                       -Intake_Method_Grp,
                                       -folds,
                                       -Prim_NOI_Dsc,
                                       -Scd_NOI_Dsc))
X_test_encode <- predict(X_test_dmy, 
                         newdata = X_test %>% 
                                    select(-Jurisdiction_State_Cde, 
                                           -Intake_Method_Grp,
                                           -folds,
                                           -Prim_NOI_Dsc,
                                           -Scd_NOI_Dsc))

test_mtx <- xgb.DMatrix(data = as(X_test_encode, "dgCMatrix"), 
                        label = as.numeric(as.character(y_test$deEscInd3000)))
# data frame format
test_df <- as.data.frame(cbind(X_test_encode, y_test["deEscInd3000"]))
names(test_df) <- make.names(names(test_df), unique = TRUE)

# save build test matrices
xgb.DMatrix.save(train_mtx, "xgbtrain.buffer")
xgb.DMatrix.save(test_mtx, "xgbtest.buffer")
save(train_df, test_df, file="xgb_train_test_df.RData")

# load build test matrices
train_mtx <- xgb.DMatrix("xgbtrain.buffer")
test_mtx <- xgb.DMatrix("xgbtest.buffer")
load("xgb_train_test_df.RData")

# ------------------------------------------
# 4. XGBoost Model
# ------------------------------------------
#benchmark baseline model
watchlist <- list(train=train_mtx, test=test_mtx)

#default parameters
params <- list(booster = "gbtree", 
               objective = "binary:logistic", 
               eta=0.3, 
               gamma=0, 
               max_depth=6, 
               min_child_weight=1, 
               subsample=1, 
               colsample_bytree=1,
               eval_metric = "error",
               eval_metric = "auc")

xgbcv <- xgb.cv(params = params, 
                data = train_mtx, 
                nrounds = 500, 
                nfold = 5, 
                showsd = T, 
                stratified = T, 
                print_every_n = 10, 
                early_stop_round = 20, 
                maximize = F)

xgb1 <- xgb.train (params = params, 
                   data = train_mtx, 
                   nrounds = 201, 
                   watchlist = watchlist, 
                   print_every_n = 10, 
                   early_stop_round = 10, 
                   maximize = F)
#model prediction
xgbpred <- predict (xgb1,test_mtx)
xgbpred <- ifelse (xgbpred > 0.5,1,0)

confusionMatrix (xgbpred, y_test$deEscInd3000, mode="everything")

xgb.save(xgb1, "xgboost.model")
xgb1 <- xgb.load("xgboost.model")

# ---------------------------------------Fine Tuning------------------------------------------------
#create tasks
traintask <- makeClassifTask (data = train_df,target = "deEscInd3000")
testtask <- makeClassifTask (data = test_df,target = "deEscInd3000")

#create learner
lrn <- makeLearner("classif.xgboost",predict.type = "response")
lrn$par.vals <- list( objective="binary:logistic", 
                      booster = "gbtree", 
                      eval_metric="error", 
                      nrounds=100L, 
                      print_every_n = 10)

#set parameter space
params <- makeParamSet(# makeDiscreteParam("booster",values = c("gbtree","gblinear")),
                       makeNumericParam("eta",lower = 0.01,upper = 0.3),
                       makeIntegerParam("max_depth",lower = 3L,upper = 10L), 
                       makeNumericParam("min_child_weight",lower = 1L,upper = 10L), 
                       makeNumericParam("subsample",lower = 0.5,upper = 1), 
                       makeNumericParam("colsample_bytree",lower = 0.5,upper = 1))

#set resampling strategy
rdesc <- makeResampleDesc("CV",stratify = T,iters=5L)

# search strategy
ctrl <- makeTuneControlRandom(maxit = 10L)

# parameter tuning
system.time( #46024.50 
  mytune_byerror <- tuneParams(learner = lrn, 
                       task = traintask, 
                       resampling = rdesc, 
                       measures = acc, 
                       par.set = params, 
                       control = ctrl, 
                       show.info = T)
)

# set hyperparameters
lrn_tune_byerror <- setHyperPars(lrn,par.vals = mytune_byerror$x)

# $eta
# [1] 0.0811994
# 
# $max_depth
# [1] 10
# 
# $min_child_weight
# [1] 7.000365
# 
# $subsample
# [1] 0.6785187
# 
# $colsample_bytree
# [1] 0.5289495

# train model
xgb_tuned_byerror <- train(learner = lrn_tune_byerror,task = traintask)

## cannot use xgb.save directly as the wrapper function changed the model class
save(xgb_tuned_byerror, xgb_tuned_byerror, file = "xgb_tuned_byErrorRate_v1s0d1.RData")
# load("xgboost_mod_tuned_v1_byErrorRate.RData")

# predict model
xgbpred_tuned_byerror <- predict(xgb_tuned_byerror,testtask)
confusionMatrix(xgbpred_tuned_byerror$data$response,
                xgbpred_tuned_byerror$data$truth, 
                mode = "everything", 
                positive = "1")
# Reference
# Prediction      0      1
# 0  20651  11408
# 1  38253 147500
# 
# Accuracy : 0.772           
# 95% CI : (0.7702, 0.7738)
# Precision : 0.7941          
# Recall : 0.9282          
# F1 : 0.8559      

auc(roc(as.factor(xgbpred_tuned_byerror$data$response), xgbpred_tuned_byerror$data$truth))
#  0.6393987

# feature importance
xgb_importance_tuned_byerror <- as.data.frame(t(getFeatureImportance(xgb_tuned_byerror )$res))
xgb_importance_tuned_byerror <- xgb_importance_tuned_byerror %>% 
                                  set_names("importance") %>%
                                  mutate(var = row.names(xgb_importance_tuned_byerror)) %>%
                                  select(var, importance) %>%
                                  arrange(desc(importance))
xgb_importance_tuned_byerror %>% filter(importance > 0) %>% nrow()
# 572 levels with importance larger than 0
fwrite(xgb_importance_tuned_byerror, "xgb_importance_tuned_byerror_v1.csv", row.names = FALSE)


# tune by AUC=============================================================
lrn <- makeLearner("classif.xgboost",predict.type = "prob")

lrn$par.vals <- list( objective="binary:logistic", 
                      booster = "gbtree", 
                      eval_metric="auc", 
                      nrounds=100L, 
                      print_every_n = 10)

# parameter tuning
system.time(#70567.43
  mytune_byAUC<- tuneParams(learner = lrn, 
                               task = traintask, 
                               resampling = rdesc, 
                               measures = auc, 
                               par.set = params, 
                               control = ctrl, 
                               show.info = T)
)

# set hyperparameters
lrn_tune_byAUC <- setHyperPars(lrn,par.vals = mytune_byAUC$x)
mytune_byAUC$x

save(mytune_byAUC, xgb_tuned_byAUC, file = "xgb_tuned_byAUC_v1s0d1.RData")

# train model
xgb_tuned_byAUC <- train(learner = lrn_tune_byAUC,task = traintask)

xgbpred_tuned_byAUC <- predict(xgb_tuned_byAUC,testtask)
confusionMatrix(xgbpred_tuned_byAUC$data$response,
                xgbpred_tuned_byAUC$data$truth, 
                mode = "everything", 
                positive = "1")

AUC::auc(roc(xgbpred_tuned_byAUC$data$response, xgbpred_tuned_byAUC$data$truth))
# 0.5818177



