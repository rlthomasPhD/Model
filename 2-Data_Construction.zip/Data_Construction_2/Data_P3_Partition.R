# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Partition meta data for model development
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse",
          "caret"
          )

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

# -------------------------
# 2. Load Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")
df <- readRDS("WC_Data_P2_v2.rds")
df_DeEscl <- readRDS("WC_DeEscl_Data_P2_v2.rds")

# -------------------------
# 3. Partition Data
# -------------------------
set.seed(3527)

buildIdx <- createDataPartition(df$deEscInd3500, 
                                p = .8, 
                                list = FALSE, 
                                times = 1)

build <- df[buildIdx,] 
holdout <- df[-buildIdx,]
build$folds <- createFolds(build$deEscInd3000, k=5, list = FALSE)

buildIdxDescl <- createDataPartition(df_DeEscl$deEscInd3500, 
                                     p = .8, 
                                     list = FALSE, 
                                     times = 1)

buildDescl <- df_DeEscl[buildIdxDescl,] 
holdoutDescl <- df_DeEscl[-buildIdxDescl,]
buildDescl$folds <- createFolds(buildDescl$deEscInd3000, k=5, list = FALSE)

# -------------------------
# 4. Save Partitions
# -------------------------

# for full segmentation
fwrite(build, "WC_Data_Build_v2.csv",row.names = FALSE)
fwrite(holdout, "WC_Data_Holdout_v2.csv",row.names = FALSE)

saveRDS(build, "WC_Data_Build_v2.rds")
saveRDS(holdout, "WC_Data_Holdout_v2.rds")

# for de-escalation only
fwrite(buildDescl, "WC_DeEscl_Data_Build_v2.csv",row.names = FALSE)
fwrite(holdoutDescl, "WC_DeEscl_Data_Holdout_v2.csv",row.names = FALSE)

saveRDS(buildDescl, file = "WC_DeEscl_Data_Build_v2.rds")
saveRDS(holdoutDescl, file = "WC_DeEscl_Data_Holdout_v2.rds")
