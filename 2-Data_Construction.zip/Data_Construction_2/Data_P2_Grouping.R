# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: 
#     1) Group numeric variables for future interaction
#     2) Group categorical variables with too many levels
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------
libs <- c("data.table", 
          "tidyverse", 
          "lubridate",
          "caret",
          "readxl",
          "openxlsx",
          "fuzzyjoin",
          "tm",
          "cluster",
          "factoextra",
          "NbClust",
          "scales",
          "knitr",
          "gRstools"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

#-------------------------- a function from Lynn: writing data to excel files--------------------
tbl_to_sheet <- function(dir, workbookName, sheetName, tbl,...) {
  # This function takes a table and write it to an excel file
  excelFile <- paste0(dir, workbookName)
  if (!file.exists(excelFile)){
    wb <- createWorkbook()
  } else{
    wb <- openxlsx::loadWorkbook(file = excelFile)
    if (any(getSheetNames(excelFile)==sheetName)) {
      openxlsx::removeWorksheet(wb, sheetName)
      openxlsx::saveWorkbook(wb, excelFile, overwrite=TRUE)
      wb <- openxlsx::loadWorkbook(file = excelFile)
    }
  }
  
  
  addWorksheet(wb, sheetName)
  writeData(wb, sheet = sheetName, x = tbl, startCol = 1, startRow = 1)
  
  openxlsx::saveWorkbook(wb, file = excelFile, overwrite = TRUE)
}

# -------------------------
# 2. Load Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")
df <- readRDS("WC_Data_P1_v2.rds")

# -------------------------
# 3. Group Data
# -------------------------

# 3.1. Group numeric variables-----------------------
df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "age_5grp")

df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight =NULL,
                      Nbin = 8, 
                      newname = "age_8grp")

df <-  weightedbucket(df, 
                      var = 'Claimant_Age_Qty', 
                      weight = NULL,
                      Nbin = 10, 
                      newname = "age_10grp")

df <-  weightedbucket(df, 
                      var = 'Tenure', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "Tenure_5grp")

df <-  weightedbucket(df, 
                      var = 'Avg_Wkly_Wge_Amt', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "Avg_Wkly_Wge_Amt_5grp")

df <-  weightedbucket(df, 
                      var = 'InjurytoReport', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "InjurytoReport_5grp")

df <-  weightedbucket(df, 
                      var = 'ReporttoEntry', 
                      weight = NULL,
                      Nbin = 5, 
                      newname = "ReporttoEntry_5grp")

# 3.2. Clean and Group raw occupations-----------------------

# pattern exploration ===========================
# ocp <- df %>% pull(Occupation_Txt)
# ocp_parse <- unlist(strsplit(ocp, " "))
# ocpFreqTerm <- as.data.frame(table(ocp_parse)) %>% 
#                 arrange(desc(Freq))
# ===============================================

# remove common unnecessary word in grouping
df <- df %>% 
      mutate(Occupation_Grp = gsub('SENIOR', '', Occupation_Txt)) %>%
      mutate(Occupation_Grp = gsub('SR ', '', Occupation_Grp))

# occupation text cleaning
df <- df %>%
  mutate(Occupation_Grp = if_else(grepl("WAIT", Occupation_Grp), "SERVER",
                                  if_else(Occupation_Grp == "BUSSER", "SERVER",
                                          if_else(grepl("FOOD", Occupation_Grp), "SERVER",
                                                  if_else(grepl("COOK|CHEF", Occupation_Grp), "COOK",
                                                          if_else(grepl("CASHIER", Occupation_Grp), "CASHIER",
                                                                  if_else(grepl("ADMIN", Occupation_Grp), "ADMIN",
                                                                          if_else(grepl("DRIV", Occupation_Grp), "DRIVER",
                                                                                  if_else(grepl("DIRVER", Occupation_Grp), "DRIVER",
                                                                                          if_else(grepl("BUS OPERATOR", Occupation_Grp), "DRIVER",
                                                                                                  if_else(grepl("CASHIER", Occupation_Grp), "CASHIER",
                                                                                                          Occupation_Grp
                                                                                                  ))))))))))) 

df <- df %>% 
  mutate(Occupation_Grp =  if_else(grepl("SALE", Occupation_Grp)&grepl("OUTSIDE|ROUTE|FIELD", Occupation_Grp), "SALES_FIELD",
                                   if_else(grepl("SALE", Occupation_Grp), "SALES_REG",
                                           if_else(Occupation_Grp == "NO DESCRIPTION", "UNKNOWN",
                                                   if_else(Occupation_Grp == "", "UNKNOWN",
                                                           if_else(grepl("LABOR", Occupation_Grp), "LABORER",
                                                                   if_else(grepl("FOREMAN", Occupation_Grp), "LABORER",
                                                                           if_else(grepl("TEACH", Occupation_Grp), "TEACHER",
                                                                                   if_else(Occupation_Grp == "CUSTA", "TEACHER",
                                                                                           if_else(grepl("WELDER", Occupation_Grp), "WELDER",
                                                                                                   if_else(grepl("CLERK", Occupation_Grp), "CLERK",
                                                                                                           if_else(grepl("TELLER", Occupation_Grp), "CLERK",
                                                                                                                   if_else(grepl("OP", Occupation_Grp)&(!grepl("SHOP", Occupation_Grp)), "OPERATOR",
                                                                                                                           if_else(grepl("SORT", Occupation_Grp), "SORTER",
                                                                                                                                   Occupation_Grp
                                                                                                                           ))))))))))))))

df <- df %>% 
  mutate(Occupation_Grp = if_else(grepl("SECU", Occupation_Grp), "SECURITY",
                                  if_else(grepl("POLICE", Occupation_Grp), "SECURITY",
                                          if_else(grepl("TECH", Occupation_Grp), "TECHNICIAN",
                                                  if_else(grepl("MACHIN", Occupation_Grp), "MECHANIC",
                                                          if_else(grepl("MECHANIC", Occupation_Grp), "MECHANIC",
                                                                  if_else(grepl("ASSEMB", Occupation_Grp), "ASSEMBLER",
                                                                          if_else(grepl("LOAD", Occupation_Grp), "LOADER",
                                                                                  if_else(grepl("WAREH", Occupation_Grp), "WAREHOUSE",
                                                                                          if_else(grepl("MED", Occupation_Grp)&(!grepl("MEDIA", Occupation_Grp)), "MEDICAL",
                                                                                                  if_else(Occupation_Grp == "CNA", "MEDICAL", # certified nurse aide
                                                                                                          if_else(Occupation_Grp == "RN", "MEDICAL", # registered nurse
                                                                                                                  if_else(grepl("NURS", Occupation_Grp), "MEDICAL",
                                                                                                                          if_else(grepl("DOCTO|DENTIST|DENTAL", Occupation_Grp), "MEDICAL",
                                                                                                                                  Occupation_Grp
                                                                                                                          ))))))))))))))  
df <- df %>% 
  mutate(Occupation_Grp = if_else(grepl("MANA|MGR|MNGR|VP", Occupation_Grp), "MANAGER",
                                  if_else(grepl("DIR", Occupation_Grp) & (!grepl("DIRECT ", Occupation_Grp)), "MANAGER",
                                          if_else(grepl("SUPV|SUPERV", Occupation_Grp), "SUPERVISOR",
                                                  if_else(grepl("LEAD", Occupation_Grp), "SUPERVISOR",
                                                          Occupation_Grp
                                                  )))))

# Check===============================================
# View(df %>% 
#        filter(grepl("DENTIST", Occupation_Txt)) %>%
#        group_by(Occupation_Txt) %>% 
#        tally() %>% 
#        arrange(desc(n)) %>%
#        head(100))
#======================================================= 

# group state and intake method---------
df <- df %>% 
  mutate(Jurisdiction_State_Cde_Grp = if_else(Jurisdiction_State_Cde %in% c("GU", "ND", "PR", "WY"), "OTH", Jurisdiction_State_Cde)) %>%
  mutate(Intake_Method_Grp = if_else(Intake_Method %in% c("Email", "Service Center Mail", "Prior TPA"), "Other", Intake_Method))

# group occupation
ocpFreq <- df %>%
            group_by(Occupation_Grp) %>%
            tally() %>%
            arrange(desc(n))

ocpTop <- ocpFreq %>% 
            filter(n>=1000) %>%
            pull(Occupation_Grp)

ocpTop30 <- ocpFreq %>% 
              head(30) %>%
              pull(Occupation_Grp)

df <- df %>% 
      mutate(Occupation_Grp1 = if_else(Occupation_Grp %in% ocpTop, Occupation_Grp, "OTHER_GRP")) %>%
      mutate(Occupation_Grp2 = if_else(Occupation_Grp %in% ocpTop30, Occupation_Grp, "OTHER_GRP"))


# 3.3. Group Other Categorical Variables-----------------------

# group acount names------------
acctFreq <- df %>% 
            select(Account_Name) %>% 
            group_by(Account_Name) %>% 
            tally() 

acctTop50 <- acctFreq  %>% 
            arrange(desc(n)) %>% 
            head(50) %>% 
            pull(Account_Name) # take the top 50 insureds

acctTop20 <- acctFreq  %>% 
              arrange(desc(n)) %>% 
              head(20) %>% 
              pull(Account_Name) # take the top 20 insureds

df <- df %>% 
       mutate(Account_Grp1 = if_else(Account_Name %in% acctTop50, Account_Name, "OTHER_GRP"),
              Account_Grp2 = if_else(Account_Name %in% acctTop20, Account_Name, "OTHER_GRP"))


# group NAIC------------
df <- df %>%  
        mutate(NAICS_Grp = substr(NAICS_Cde,1,2),
               NAICS_Grp = if_else(is.na(NAICS_Grp),"missing", NAICS_Grp)) 


# Group Nature of Injury---------
PrimNOI_top20 <- df %>%
                  group_by(Prim_NOI_Dsc) %>%
                  tally() %>%
                  arrange(desc(n)) %>%
                  head(20) %>%
                  pull(Prim_NOI_Dsc)

ScdNOI_top10 <- df %>%
                group_by(Scd_NOI_Dsc) %>%
                tally() %>%
                arrange(desc(n)) %>%
                head(10) %>%
                pull(Scd_NOI_Dsc)

df <- df %>% 
        mutate(PrimNOI_Grp20 = if_else(Prim_NOI_Dsc %in% PrimNOI_top20, Prim_NOI_Dsc, "OTHER_GRP"),
               ScdNOI_Grp10 = if_else(Scd_NOI_Dsc %in% ScdNOI_top10, Scd_NOI_Dsc, "OTHER_GRP"))

# Group Part of Body--------
PrimPOB_top30 <- df %>%
                  group_by(Prim_POB_Dsc) %>%
                  tally() %>%
                  arrange(desc(n)) %>%
                  head(30) %>%
                  pull(Prim_POB_Dsc)

ScdPOB_top10 <- df %>%
                group_by(Scd_POB_Dsc) %>%
                tally() %>%
                arrange(desc(n)) %>%
                head(10) %>%
                pull(Scd_POB_Dsc)

df <- df %>% 
      mutate(PrimPOB_Grp30 = if_else(Prim_POB_Dsc %in% PrimPOB_top30, Prim_POB_Dsc, "OTHER_GRP"),
             ScdPOB_Grp10 = if_else(Scd_POB_Dsc %in% ScdPOB_top10, Scd_POB_Dsc, "OTHER_GRP"))

# Group Occurrence---------
Occur_top30 <- df %>%
                group_by(Occur_Dsc) %>%
                tally() %>%
                arrange(desc(n)) %>%
                head(30) %>%
                pull(Occur_Dsc)

df <- df %>% 
      mutate(Occur_Grp30 = if_else(Occur_Dsc %in% Occur_top30, Occur_Dsc, "OTHER_GRP"))


# -------------------------
# 4. Save Data
# -------------------------
saveRDS(df, file = "WC_Data_P2_v2.rds")



# moddfeda <- eda(moddf, byvar = TRUE)
# system.time(# 79.657
#   moddfedaBySeg <- eda(moddf, 
#                        crossvar = c("deEscInd3500","Year"), 
#                        cross_only = TRUE, 
#                        ignore_list = c("Claim_ID", 
#                                        "Claim_Num", 
#                                        "Occupation_Txt",
#                                        "Accident_Note_Text", 
#                                        "Injury_Note_Text",
#                                        "NAICS_Cde",
#                                        "Occupation_Grp"))
# )

