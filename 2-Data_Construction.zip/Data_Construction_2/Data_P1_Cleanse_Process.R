# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Cleanse and process meta data
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse", 
          "lubridate",
          "caret",
          "readxl",
          "openxlsx",
          "tm",
          "geosphere"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}

lapply(libs, require, character.only = TRUE)

# -------------------------
# 2. Load Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")
df <- readRDS("WC_all_data_v2.rds")

reg <- fread("stateRegion.csv", stringsAsFactors = FALSE)
POBdef <- read_excel("part of body.xlsx")
NOIdef <- read_excel("Nature of Injury.xlsx")
Occdef <- fread("Occ_def.csv")
zip_location <- fread("us-zip-code-latitude-and-longitude.csv")

# -------------------------
# 3. Cleanse Data
# -------------------------

df <- df %>%
      filter(Year < 2018) %>% #2018 has not been developed enough
      mutate_at(vars(Claim_System_Entry_Dte, 
                     Report_dte, 
                     Injury_Dte),
                funs(as.Date(.,"%d%b%Y"))) %>%
      mutate_at(vars(current_total_incurred, 
                     Indemnity_Incurred, 
                     Medical_Incurred, 
                     Expense_Incurred,
                     Tenure,
                     Claimant_Age_Qty), 
            funs(as.numeric(.))) %>%
      mutate_at(vars(current_total_incurred, 
                     Indemnity_Incurred, 
                     Medical_Incurred, 
                     Expense_Incurred,
                     Tenure), 
                funs(if_else(is.na(.), 0, .))) %>%
      filter(current_total_incurred >= 0) %>%    # quite a lot from Service Center (SC) are not valid 
      filter(Claimant_Age_Qty >= 15 &            # 335 record < 15
               Claimant_Age_Qty <=80 &           # 19471 record >80, 2028 records == 99 (majarity of them came from SC, some came from EDI)
               !is.na(Claimant_Age_Qty)) %>%     #324 is NA
      mutate(InjurytoReport = as.numeric(Report_dte - Injury_Dte),
             ReporttoEntry = as.numeric(Claim_System_Entry_Dte - Report_dte), 
             Avg_Wkly_Wge_Amt = ifelse(Avg_Wkly_Wge_Amt == 99999, 0, Avg_Wkly_Wge_Amt)) %>%
      mutate_if(is.integer, funs(as.character(.))) %>%
      mutate_at(vars(Occupation_Txt, Accident_Note_Text, Injury_Note_Text), 
                removePunctuation) %>%
      mutate_at(vars(Occupation_Txt, Accident_Note_Text, Injury_Note_Text), 
                funs(iconv(., "ASCII", "UTF-8", sub=""))) %>%
      mutate_at(vars(Occupation_Txt, Accident_Note_Text, Injury_Note_Text), 
                funs(str_trim(., side = "both"))) %>%
      mutate_at(vars(Occupation_Txt, Accident_Note_Text, Injury_Note_Text), 
                funs(str_squish(.))) %>%
      mutate(Occupation_Txt = gsub('\t', '', Occupation_Txt)) %>%
      mutate_at(vars(Secondary_Nature_Of_Injury_Cde, 
                     Secondary_Part_Of_Body_Cde,
                     Initial_Trtm_Cde),
                funs(if_else(is.na(.), "missing", .))) 

############### zipcode check ########################
check <- df %>% 
          select(Claimant_Postal_Cde, Cust_Postal_Cde, Jurisdiction_State_Cde) %>%
          mutate(Claimant_zip_length = nchar(Claimant_Postal_Cde),
                 Cust_zip_length = nchar(Cust_Postal_Cde))

table(check$Claimant_zip_length)

# 1       3       4       5       6       7       8       9 
# 365       1       1    3718       3     345  169815 1260226 

table(check$Cust_zip_length)
# 1      4      5      7      8      9 
# 642166     72    365      9  96642 686024 

check %>% 
  filter(Claimant_zip_length < 8) %>% 
  group_by(Jurisdiction_State_Cde, 
           Claimant_Postal_Cde) %>% 
  tally()%>%
  arrange(desc(n))%>% 
  View() 

check %>% 
  filter(Cust_zip_length < 8 & !is.na(Cust_zip_length)) %>% 
  group_by(Jurisdiction_State_Cde, 
           Cust_Postal_Cde,
           Cust_zip_length) %>% 
  tally() %>%
  arrange(desc(n))%>% 
  View() 

# majority zip come with trailing zeroes, but some do not

############### zipcode check ends ########################

# cleanse zipcode
df <- df %>% 
          mutate(Claimant_zip_length = nchar(Claimant_Postal_Cde),
                 Cust_zip_length = nchar(Cust_Postal_Cde)) %>%
          mutate(Claimant_Postal_Cde = if_else(Claimant_zip_length > 7, 
                                               str_pad(Claimant_Postal_Cde, 9, side="left", pad="0"), 
                                               str_pad(Claimant_Postal_Cde, 9, side="right", pad="0")), 
                 Cust_Postal_Cde = if_else(Claimant_zip_length > 7, 
                                           str_pad(Cust_Postal_Cde, 9, side="left", pad="0"), 
                                           str_pad(Cust_Postal_Cde, 9, side="right", pad="0"))) %>%
          mutate_at(vars(Claimant_Postal_Cde, Cust_Postal_Cde),
                    funs(substr(., 1, 5))) %>% 
          select(-Claimant_zip_length, -Cust_zip_length)
        
# -------------------------
# 4. Process Data
# -------------------------

df <- df %>%
      left_join(POBdef %>% 
                  select(Part_of_Body_Cde, 
                         Part_of_Body_Category_Cde, 
                         Part_of_Body_Dsc, 
                         Part_of_Body_Category_Dsc), 
                by = c("Primary_Part_Of_Body_Cde" = "Part_of_Body_Cde")) %>%
      rename(Prim_POB_Category_Cde = Part_of_Body_Category_Cde, 
             Prim_POB_Dsc = Part_of_Body_Dsc,
             Prim_POB_Category_Dsc = Part_of_Body_Category_Dsc) %>%
      left_join(POBdef %>% 
                  select(Part_of_Body_Cde, 
                         Part_of_Body_Category_Cde, 
                         Part_of_Body_Dsc, 
                         Part_of_Body_Category_Dsc), 
                by = c("Secondary_Part_Of_Body_Cde" = "Part_of_Body_Cde")) %>%
      rename(Scd_POB_Category_Cde = Part_of_Body_Category_Cde, 
             Scd_POB_Dsc = Part_of_Body_Dsc,
             Scd_POB_Category_Dsc = Part_of_Body_Category_Dsc) %>%
      left_join(Occdef %>% 
                  mutate_if(is.numeric, as.character), 
                by = "Occurrence_Cde") %>%
      rename(Occur_Dsc = Definition) %>%
      left_join(NOIdef %>% 
                  select(Nature_of_Injury_Code, Nature_of_Injury_Description) %>%
                  mutate(Nature_of_Injury_Code = gsub("(^|[^0-9])0+", "\\1", Nature_of_Injury_Code, perl = TRUE)), 
                by = c("Primary_Nature_Of_Injury_Cde" = "Nature_of_Injury_Code")) %>%
      rename(Prim_NOI_Dsc = Nature_of_Injury_Description) %>%
      left_join(NOIdef %>% 
                  select(Nature_of_Injury_Code, Nature_of_Injury_Description) %>%
                  mutate(Nature_of_Injury_Code = gsub("(^|[^0-9])0+", "\\1", Nature_of_Injury_Code, perl = TRUE)), 
                by = c("Secondary_Nature_Of_Injury_Cde" = "Nature_of_Injury_Code")) %>%
      rename(Scd_NOI_Dsc = Nature_of_Injury_Description) %>%
      mutate_at(vars(Scd_POB_Category_Cde, 
                     Scd_POB_Dsc,
                     Scd_POB_Category_Dsc,
                     Scd_NOI_Dsc),
                funs(if_else(is.na(.), "missing", .))) %>% 
      left_join(reg %>% select(-"State Name"), by= c("Jurisdiction_State_Cde" = "State" )) %>%
      mutate(Region = if_else(is.na(Region), "missing", Region))


# join zip code location
zip_location$Zip <- str_pad(zip_location$Zip, 5, side = "left", pad = "0") 

df <- df %>%
          left_join(zip_location %>% 
                      select(Zip, Latitude, Longitude), 
                    by = c("Claimant_Postal_Cde" = "Zip")) %>%
          rename(Claimant_Latitude = Latitude,
                 Claimant_Longitude = Longitude) %>%
          left_join(zip_location %>% 
                      select(Zip, Latitude, Longitude), 
                    by = c("Cust_Postal_Cde" = "Zip")) %>%
          rename(Cust_Latitude = Latitude,
                 Cust_Longitude = Longitude)

################## sanity check #################
# claimant zip 1.65% notmatched, mostly are caused by missing zip
# cust zip 45.88% not matched, 45% cust zip are "caused by missing zip

df %>% filter(is.na(Claimant_Latitude)) %>% group_by(Claimant_Postal_Cde) %>% tally() %>% arrange(desc(n)) %>% head(10) 
df %>% filter(is.na(Cust_Latitude)) %>% group_by(Cust_Postal_Cde) %>% tally() %>% arrange(desc(n)) %>% head(10)
################## sanity check ends #################

# calculate travel distance to work in miles
df <- df %>% 
        mutate(Dist_to_work = distGeo(cbind(Claimant_Longitude, Claimant_Latitude),
                                      cbind(Cust_Longitude, Cust_Latitude)) * 0.000621371) # convert meter to miles
# 25554 zeroes and 671285 missing in distance

df <- df %>% 
  mutate(deEscInd3500 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 3500, 1, 0))) %>%
  mutate(deEscInd3000 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 3000, 1, 0))) %>%
  mutate(deEscInd2500 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 2500, 1, 0))) %>%
  mutate(deEscInd2000 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 2000, 1, 0))) %>%
  mutate(deEscInd1500 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 1500, 1, 0))) %>%
  mutate(deEscInd1000 = as.factor(if_else(Initial_Seg != "SUS" & current_total_incurred <= 1000, 1,0))) %>% 
  mutate(over100kFlg = as.factor(if_else(current_total_incurred > 100000, 1,0))) %>%
  mutate(zeroLossFlg = if_else(current_total_incurred == 0, 1, 0))

# -------------------------
# 5. Save Data
# -------------------------
saveRDS(df, file = "WC_Data_P1_v2.rds")

# save data for claims de-esclation only
saveRDS(df %>% filter(Initial_Seg != 'SUS'), file = "WC_DeEscl_Data_P1_v2.rds")

# save data for claims esclation only
saveRDS(df %>% filter(Initial_Seg == 'SUS'), file = "WC_Escl_Data_P1_v2.rds")
