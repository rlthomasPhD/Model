# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 05/09/2019
# 
# Objective: Further group the data using clustering analysis on build dataset
# ===========================================================================================


# -------------------------
# 1. Load Packages
# -------------------------
libs <- c("data.table", 
          "tidyverse", 
          "lubridate",
          "caret",
          "readxl",
          "openxlsx",
          "fuzzyjoin",
          "tm",
          "cluster",
          "factoextra",
          "scales",
          "knitr",
          "gRstools"
)

if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

# -------------------------
# 2. Load Data
# -------------------------
# Rgird path
setwd("/gs_data/CynthiaH/NI WC Claims")

# VM path
setwd("//client/R$/CynthiaH/NI WC Claims")

build <- readRDS("WC_DeEscl_Data_Build_v2.rds")
holdout <- readRDS("WC_DeEscl_Data_Holdout_v2.rds")

load("EDA_clustering.RData")

# -------------------------
# 3. Join Cluster Grouping
# -------------------------

build <- build %>%
          left_join(PrimPOB %>% 
                      select(Prim_POB_Dsc, 
                             starts_with("km"), 
                             starts_with("pam")), 
                    by = c("Prim_POB_Dsc")) %>%
          mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
          rename_at(vars(starts_with("km"), starts_with("pam")),
                    funs(paste0("PrimPOB_",.))) %>%
          left_join(PrimNOI %>% 
                      select(Prim_NOI_Dsc, 
                             starts_with("km"), 
                             starts_with("pam")), 
                    by = c("Prim_NOI_Dsc")) %>%
          mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
          rename_at(vars(starts_with("km"), starts_with("pam")),
                    funs(paste0("PrimNOI_",.))) %>%
          left_join(Occur %>% 
                      select(Occur_Dsc, 
                             starts_with("km"), 
                             starts_with("pam")), 
                    by = c("Occur_Dsc")) %>%
          mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
          rename_at(vars(starts_with("km"), starts_with("pam")),
                    funs(paste0("Occur_",.)))

holdout <- holdout %>%
            left_join(PrimPOB %>% 
                        select(Prim_POB_Dsc, 
                               starts_with("km"), 
                               starts_with("pam")), 
                      by = c("Prim_POB_Dsc")) %>%
            mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
            rename_at(vars(starts_with("km"), starts_with("pam")),
                      funs(paste0("PrimPOB_",.))) %>%
            left_join(PrimNOI %>% 
                        select(Prim_NOI_Dsc, 
                               starts_with("km"), 
                               starts_with("pam")), 
                      by = c("Prim_NOI_Dsc")) %>%
            mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
            rename_at(vars(starts_with("km"), starts_with("pam")),
                      funs(paste0("PrimNOI_",.))) %>%
            left_join(Occur %>% 
                        select(Occur_Dsc, 
                               starts_with("km"), 
                               starts_with("pam")), 
                      by = c("Occur_Dsc")) %>%
            mutate_at(vars(starts_with("km"), starts_with("pam")), funs(as.character(.))) %>%
            rename_at(vars(starts_with("km"), starts_with("pam")),
                      funs(paste0("Occur_",.)))

# -------------------------
# 4. Export Data 
# -------------------------
  
fwrite(build, "WC_DeEscl_Data_Build_wClstr_v2.csv",row.names = FALSE)
fwrite(holdout, "WC_DeEscl_Data_Holdout_wClstr_v2.csv",row.names = FALSE)

saveRDS(build, file = "WC_DeEscl_Data_Build_wClstr_v2.rds")
saveRDS(holdout, file = "WC_DeEscl_Data_Holdout_wClstr_v2.rds")



