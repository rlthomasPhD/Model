# ===========================================================================================
# Project: NI WC Claims Segmentation
# Author: Cynthia He
# Date: 04/09/2019
# 
# Objective: Combine data by year into a meta data set
# ===========================================================================================

# -------------------------
# 1. Load Packages
# -------------------------

libs <- c("data.table", 
          "tidyverse",
          "gRstools"
          )


if (length(setdiff(libs, rownames(installed.packages()))) > 0) {
  install.packages(setdiff(libs, rownames(installed.packages())))  
}
lapply(libs, require, character.only = TRUE)

# source("//gs_data/tools/libertyr_update/EDA_default.R")

# -------------------------
# 2. Load and Combine Data
# -------------------------
setwd("/gs_data/CynthiaH/NI WC Claims")

df2013_14 <- fread("2013_14.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2015_16 <- fread("2015_16.csv", encoding='UTF-8', stringsAsFactors=FALSE)
df2017_18 <- fread("2017_18.csv", encoding='UTF-8', stringsAsFactors=FALSE)

# names(df2013_14)

# check format consistency
sum(names(df2013_14) != names(df2015_16)) 
sum(names(df2015_16) != names(df2017_18))

# Combine data
df <- rbind(df2013_14, 
            df2015_16, 
            df2017_18)

# ----------------------------------
# 4. Compare with Previous Version
# ----------------------------------
df_v1 <- fread("data_v1/WC_all_data.csv", encoding='UTF-8', stringsAsFactors=FALSE)

# 4.1 column differences-----------------------------
setdiff(names(df), names(df_v1))

# [1] "Current_PMT_Cde"        "Current_Controverted_I" "Top Account Name"       "Lost_Time_Cde"         
# [5] "Report_Lag"             "Runoff/Not Runoff"      "Cust_Postal_Cde"        "Claimant_Postal_Cde"   
# [9] "accident_txt"           "injury_txt"             "Dataset"                "CRC_Rating_Plan_Code"  

setdiff(names(df_v1), names(df))
# "Accident_Note_Text" "Injury_Note_Text"   "Initial_Seg"  

################################## data issue check ##########################################

tmp <- df %>% select(accident_txt) %>% mutate(accident_txt = iconv(accident_txt, "ASCII", "UTF-8", sub=""))
tmp_nchar <- apply(tmp, 2, nchar)
summary(tmp_nchar)
# accident_txt   
# Min.   :  0.00  
# 1st Qu.: 67.00  
# Median : 92.00  
# Mean   : 87.84  
# 3rd Qu.:117.00  
# Max.   :129.00  
# NA's   :45 

# longest text has 129 characters
# 45 missing

# compare with the previsous data
sum(is.na(df_v1$Accident_Note_Text), na.rm = TRUE) # 0 count 
sum(df_v1$Accident_Note_Text =="", na.rm = TRUE) # 448803 count, 25% missing

sum(tmp_nchar==0, na.rm = TRUE)   # 4255 records
sum(tmp_nchar==120, na.rm = TRUE) # 314377 records
sum(tmp_nchar>120, na.rm = TRUE)  # 6364 records

df$accident_txt[which(is.na(tmp_nchar))][1:5]
unique(df$accident_txt[which(is.na(tmp_nchar))])
# NA, original text values are missing
# NA NA NA NA NA

df$accident_txt[which(tmp_nchar==120)][1:5]
# [1] "ASSOICATE HAS BEEN INJURING HERSELF ON AND OFF NOW WITH HER RESTRICTIONS. ASSOCIATE SAID KEYBOARD WAS ABOUT  TO DROP AND"
# [2] "EMPLOYEE WAS DECENDING FROM A PORTABLE HOOK LADDER WHEN HIS RIGHT FOOT SLIPPED FROM THE 3RD RUNG OF THE LADDER.  HIS LEF"
# [3] "ASSOCIATE LIFTING BLACK RAILING MATERIAL (LL BUILDING) IN CONSOLIDATION LANE 49 WHEN A PIECE SLIPPED STRIKING HIM IN THE"
# [4] "ELIZABETH WAS WORKING ON DIVERT 15 WHEN SHE WALKED PAST PALLET C2 AND SCRAPED HER LEFT ARM ON SKU 866616. THIS CAUSE A S"
# [5] "DRIVER STATES WAS WALKING TO THE FRONT DOOR TO MAKE DELIVERY AT RURAL RESIDENTIAL ADDRESS WHEN A SMALL STRAY DOG CAME UP"

df$accident_txt[which(tmp_nchar>120)][1:5]
# [1] "ASSOCIATE WAS LIFTING 3/4\"\" PLYWOOD ONTO THE PANEL SAW AND HURT HIS LEFT WRIST.  THE PAIN HAS SINCE INCREASED WHEN LIFTIN"  
# [2] "ASSOCIATE WAS HELPING A CUSTOMER LOAD 3/4\"\" PT PLYWOOD ONTO THEIR CART. THE CUSTOMER DROPPED THE PLYWOOD AND IT LANDED ON"  
# [3] "ROBERT WAS CUTTING PVC PIPE WITH HAND CUTTER WHEN BLADE CUT EDGE OF MIDDLE FINGER LEFT HAND GIVING HIM A 1/4\"\" LACERATION"

## empty cell significantly reduced>>>>>>>>>>>>>>>
## text are still cut off at 120 characters!!! nchar > 120 is caused by special symbol >>>>>>>>>>>>>>>

tmp2 <- df %>% select(injury_txt) %>% mutate(injury_txt = iconv(injury_txt, "ASCII", "UTF-8", sub=""))
tmp2_nchar <- apply(tmp2, 2, nchar)
summary(tmp2_nchar)
# Min.   :  0.00  
# 1st Qu.: 11.00  
# Median : 21.00  
# Mean   : 26.29  
# 3rd Qu.: 32.00  
# Max.   :124.00  
# NA's   :345   

# longest text has 124 characters
# 345 na

# compare with the previsous data
sum(is.na(df_v1$Injury_Note_Text), na.rm = TRUE) # 0 count 
sum(df_v1$Injury_Note_Text =="", na.rm = TRUE) # 729268 count, 41% missing

sum(tmp2_nchar==0, na.rm = TRUE)   # 367005 records
sum(tmp2_nchar==120, na.rm = TRUE) # 15616 records
sum(tmp2_nchar>120, na.rm = TRUE)  # 431 records

df$injury_txt[which(is.na(tmp2_nchar))][1:5]
unique(df$injury_txt[which(is.na(tmp2_nchar))])
# NA, original text values are missing

df$injury_txt[which(tmp2_nchar == 120)][1:5]
# [1] "EMP WALKING IN FOODS MAIN AISLE AND TRIED TO AVOID 2 MEMBER'S CARTS WHEN HE TURNED ABRUPTLY, HE FELT A PULL IN HIS GROIN"
# [2] "CATHERINE WAS ON A LADDER GETTING A SUITCASE DOWN.  A LARGE FROSTED PIECE OF HEAVEY PLASTIC FELL FOREWARD HITTING HER LA"
# [3] "I WAS IN RUSH HOUR TRAFFIC AND THE CAR BEHIND ME QUICKLY STOPPED SHORT AND THE CAR BEHIND HIM HIT HIS CAR AND IN TURN HI"
# [4] "ADRIANA WAS TRYING TO GRAB PANS OFF OF THE THE SHELF AND THEY ALL FELL ON TOP OF HERBIE. THIS HIT HIM INTHE FACE, EYE AN"
# [5] "HE WAS WORKING HIS NORMAL SHIFT AND HIS FOOT STARTED HURTING THEN THE NEXT DAY HE WOKE UP AND HIS RIGHT FOOT WAS HURTING"

df$injury_txt[which(tmp2_nchar > 120)][1:3]
# [1] "ALFONSO WAS PICKING UP A PC. OF 6\"\" SCH. 10 PIPE WITH AARON COMPOS FROM THE BANDSAW TABLE, WAS PUTTING IT ON A PIPE CART."
# [2] "EE WROTE \"\" WHEN OPENING AND CLOSING VALVE 240H FELT DISCOMFORT IN MY BACK UPPER RIGHT QUADRANT.  THIS IS NOT UNCOMMON DU"
# [3] "EMPLOYEE SLIPPED ON ICE WHILE CARRYING 3\"\" TUBE STEEL. THE BEAM FELL HITTING HIS HEAD AND CHEST AND  LANDED ON LOWER BACK"

## empty cell significantly reduced>>>>>>>>>>>>>>>
## text are still cut off at 120 characters!!! nchar > 120 is caused by special symbol >>>>>>>>>>>>>>>

################################## data issue check end ##########################################


# 4.2 row differences-----------------------------

nrow(df_v1) - nrow(df)  #11960

claims_reduced <- setdiff(df_v1$Claim_ID, df$Claim_ID)
row_diff_df <- df_v1 %>% filter(Claim_ID %in% claims_reduced)
row_diff_eda <- eda(row_diff_df, byvar = TRUE) 
row_diff_eda$num_summary # 45% of the data have missing current_total_incurred
row_diff_eda$cat_summary # all of the claims are Final, with SUS as initial segment, higher than average missing rate in the text notes fields

fwrite(row_diff_df, file= "row_diff_new_vs_v1.csv", row.names = FALSE)

# 4.3 minor processing-----------------------------

## change columns names for consisitency
df <- df %>% 
      rename(Accident_Note_Text = accident_txt,
              Injury_Note_Text = injury_txt) %>%
      mutate(Initial_Seg = substr(Dataset, 1,3)) %>%
      mutate(Initial_Seg = if_else(Initial_Seg == "Rem", "SUS", Initial_Seg))

## sanity check
# setdiff(names(df_v1), names(df))              
# character(0) 

# 4.4 systematic comparison-----------------------------
test <- df %>% 
  select(one_of(names(df_v1))) %>% 
  rename_at( vars(-Claim_ID), funs(paste0(.,"_new"))) %>%
  left_join(df_v1, by = "Claim_ID")

test <- test %>% 
          mutate_at(vars(current_total_incurred, 
                         Indemnity_Incurred, 
                         Medical_Incurred, 
                         Expense_Incurred,
                         current_total_incurred_new, 
                         Indemnity_Incurred_new, 
                         Medical_Incurred_new, 
                         Expense_Incurred_new), 
                    funs(as.numeric(.))) %>%
          mutate_at(vars(current_total_incurred, 
                                Indemnity_Incurred, 
                                Medical_Incurred, 
                                Expense_Incurred,
                                current_total_incurred_new, 
                                Indemnity_Incurred_new, 
                                Medical_Incurred_new, 
                                Expense_Incurred_new), 
                           funs(if_else(is.na(.), 0, .))) %>%
         mutate_at(vars(Claim_System_Entry_Dte_new, 
                               Report_dte_new, 
                               Injury_Dte_new),
                          funs(as.Date(.,"%d%b%Y")))


for (col in setdiff(names(df_v1), "Claim_ID")){
  col2 <- paste0(col, "_new")
  if(endsWith(col, "dte") | endsWith(col, "Dte")){
    comp <- sum(test[[col]] == test[[col2]]) == nrow(test)
  } else{
  comp <- identical(test[[col]], test[[col2]]) # identical() cannout be used on date variables
  }
  
  if (!comp){
    print(col2)
  }
}

# [1] "Account_Name_new"
# [1] "Occupation_Txt_new"
# [1] "Accident_Note_Text_new"
# [1] "Injury_Note_Text_new"

test %>% 
  select(Account_Name, Account_Name_new) %>% 
  filter(Account_Name_new != Account_Name) 
# only punctuation difference, """" >>> ""

test %>% 
  select(Occupation_Txt, Occupation_Txt_new) %>% 
  filter(Occupation_Txt_new != Occupation_Txt) 
# same reason as above

# -------------------------
# 3. Save Data
# -------------------------
fwrite(df, "WC_all_data_v2.csv",row.names = FALSE )
saveRDS(df, file = "WC_all_data_v2.rds")

